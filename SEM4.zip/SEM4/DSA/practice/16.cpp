#include<iostream>
using namespace std;

int smallest(int arr[],int n,int i)
{
    int j,temp,small,pos;

    small=arr[i];
    pos=i;

    for(int j=i+1;j<n;j++)
    {
        if(arr[j]<small)
        {
            small=arr[j];
            pos=j;
        }
    }

    return pos;
}

int main()
{
    int size,pos,temp;
    cout<<"Enter the size:";cin>>size;

    int arr[size];

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    for(int i=0;i<size;i++)
    {
        pos=smallest(arr,size,i);

        temp=arr[i];
        arr[i]=arr[pos];
        arr[pos]=temp;
    }

    cout<<"Sorted array is:"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<endl;
    }

    return 0;
}