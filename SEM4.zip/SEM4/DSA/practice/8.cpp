#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*prev;
    node*next;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    int num;
    node*new_node;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node = new node();
        new_node->data=num;
    

    if(start==NULL)
    {
        new_node->next=NULL;
        new_node->prev=NULL;
        start=new_node;
        rear=new_node;
    }
    else
    {
        rear->next=new_node;
        new_node->prev=rear;
        rear=new_node;
    }
    cout<<"Enter the data:";cin>>num;
    }
    return start;
}

node*display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
        cout<<ptr->data<<" ";
        ptr=ptr->next;
        }
         cout<<ptr->data;
         cout<<endl;
    }
    return start;
}

node*rev_disp(node*start)
{
    node*ptr;
    ptr=rear;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->prev!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->prev;
        }
        cout<<ptr->data;
        cout<<endl;
    }
    return start;
}

int main()
{
    int option;

    do{
        cout<<"1.CREATE"<<endl;
        cout<<"2.DISPLAY"<<endl;
        cout<<"3.REVERSE DISPLAY"<<endl;
        cout<<"4.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            start=create(start);
            cout<<endl;
            break;

            case 2:
            start=display(start);
            cout<<endl;
            break;

            case 3:
            start=rev_disp(start);
            cout<<endl;
            break;

            case 4:
            return 0;
        }
    }while(option!=4);

    return 0;
}