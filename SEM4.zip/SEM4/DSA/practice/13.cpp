#include<iostream>
using namespace std;

int main()
{
    int size,item,pos=-1;
    cout<<"Enter the size:";cin>>size;

    int arr[size];

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter the item to search:";cin>>item;

    for(int i=0;i<size;i++)
    {
        if(arr[i]==item)
        {
           pos=i;
           cout<<"Element found at position:"<<pos<<endl;
           break;
        }
    }

    if(pos==-1)
    {
        cout<<"Element not found";
    }
}