#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*top=NULL;

node*push(node*top)
{
    node*new_node;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    if(top==NULL)
    {
        new_node->next=NULL;
        top=new_node;
    }
    else
    {
        new_node->next=top;
        top=new_node;
    }
    return top;
}

node*display(node*top)
{
    node*ptr;
    ptr=top;

    if(top==NULL)
    {
        cout<<"Stack is empty";
    }
    else
    {
        while(ptr!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<endl;
    }
    return top;
}

node*pop(node*top)
{
    node*ptr;

    if(top==NULL)
    {
        cout<<"Stack empty";
    }
    else
    {
        ptr=top;
        top=top->next;
        free(ptr);
    }
    return top;
}

int peep(node*top)
{
    return top->data;
}

int main()
{
    int option,val;

    do
    {
        cout<<"1.Push"<<endl;
        cout<<"2.Display"<<endl;
        cout<<"3.Pop"<<endl;
        cout<<"4.Peep"<<endl;
        cout<<"5.Exit"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            top=push(top);
            cout<<endl;
            break;

            case 2:
            top=display(top);
            cout<<endl;
            break;

            case 3:
            top=pop(top);
            break;

            case 4:
            val=peep(top);
            cout<<"Value is:"<<val<<endl;
            break;

            case 5:
            return 0;
        }
    }while(option!=5);
  
    return 0;
}