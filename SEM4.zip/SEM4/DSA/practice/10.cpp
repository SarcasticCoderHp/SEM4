//DOUBLY WITH ALL OPERATIONS

#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
    node*prev;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node=new node();
        new_node->data=num;

        if(start==NULL)
        {
            start=new_node;
            new_node->next=NULL;
            new_node->prev=NULL;
            rear=new_node;
        }
        else
        {
            rear->next=new_node;
            new_node->prev=rear;
            rear=new_node;
        }
        cout<<"Enter the data:";cin>>num;
    }
    return start;
}

node*display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }
    return start;
}

node*reverse(node*start)
{
    node*ptr;
    ptr=start;

    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }
    while(ptr->prev!=NULL)
    {
        cout<<ptr->data<<" ";
        ptr=ptr->prev;
    }
    cout<<ptr->data;
    cout<<endl;

    return start;
}

node*insert_begin(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node=new node();
    new_node->data=num;

    new_node->next=start;
    new_node->prev=NULL;
    start=new_node;

    display(start);
    return start;
}

node*insert_end(node*start)
{
    node*new_node,*ptr;  ptr=start;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node=new node();
    new_node->data=num;

    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }
    
    ptr->next=new_node;
    new_node->prev=ptr;

    display(start);
    return start;
}

node*delete_beg(node*start)
{
    node*ptr;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        ptr=start;
        start=start->next;
        free(ptr);
       }

    display(start);
    return start;
}

node*delete_end(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
      while(ptr->next!=NULL)
      {
        ptr=ptr->next;
      }
      ptr->prev->next=NULL;
      free(ptr);
    }

    display(start);
    return start;
}

node*delete_mid(node*start)
{
    node*ptr,*preptr;
    ptr=start;

    int val;
    cout<<"Enter the node to delete:";cin>>val;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->data!=val)
        {
            ptr=ptr->next;
        }

        preptr=ptr->prev;
        preptr->next=ptr->next;
        ptr->next->prev=preptr;

        free(ptr);
    }
    display(start);
    return start;
}

int main()
{
    int option;

    do
    {
        cout<<"1.CREATE"<<endl;
        cout<<"2.DISPLAY"<<endl;
        cout<<"3.REVERSE"<<endl;
        cout<<"4.INSERT BEGIN"<<endl;
        cout<<"5.INSERT END"<<endl;
        cout<<"6.DELETE BEGIN"<<endl;
        cout<<"7.DELETE END"<<endl;
        //cout<<"8.INSERT AFTER"<<endl;
        cout<<"9.DELETE MIDDLE"<<endl;
        cout<<"10.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            start=create(start);
            cout<<"Linked list created"<<endl;
            break;

            case 2:
            display(start);
            cout<<endl;
            break;

            case 3:
            start=reverse(start);
            break;

            case 4:
            start=insert_begin(start);
            cout<<endl;
            break;

            case 5:
            start=insert_end(start);
            cout<<endl;
            break;

            case 6:
            start=delete_beg(start);
            cout<<endl;
            break;

            case 7:
            start=delete_end(start);
            cout<<endl;
            break;

          /*  case 8:
            start=insert_after(start);
            cout<<endl;
            break;*/

            case 9:
            start=delete_mid(start);
            cout<<endl;
            break;

            case 10:
            return 0;
        }
    } while (option!=10);
    return 0;
}
