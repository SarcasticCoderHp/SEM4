#include <iostream>
#define MAX 10
using namespace std;

int queue[MAX];
int front=-1,rear=-1;

void enqueue()
{
    int num;
    cout<<"Enter a number to insert in queue:";cin>>num;

    if(rear==MAX-1)
    {
        cout<<"Overflow";
    }
    else
    {
        if(front==-1 && rear==-1)
        {
            front=rear=0;
        }
        else
        {
            rear++;
            queue[rear]=num;
        }
    }
}

int dequeue()
{
    int val;

    if(front==-1 && front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        val=queue[front];
        front++;
    }
    return front;
}

int peek()
{
    return(queue[front]);
}

void display()
{
    if(front==-1 && front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        cout<<endl;
        for(int i=front;i<=rear;i++)
        {
            cout<<queue[i]<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.Enqueue"<<endl;
        cout<<"2.Dequeue"<<endl;   
        cout<<"3.Peek"<<endl;
        cout<<"4.Display"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            enqueue();
            break;

            case 2:
            val=dequeue();
            cout<<"Deleted value:"<<val<<endl;
            break;

            case 3:
            val=peek();
            cout<<"Value is:"<<val<<endl;
            break;

            case 4:
            display();
            break;

            case 5:
            return 0;
        } 
    }while(option!=5);
    return 0;
}