#include<iostream>
#define MAX 10
using namespace std;

int queue[MAX];
int front=-1,rear=-1;

void enqueue()
{
    int num;

    if(front==rear+1 || front==0 && rear==MAX-1)
    {
        cout<<"Overflow";
    }

    else if(front==-1 && rear==-1)
    {
        cout<<"Enter the number:";cin>>num;
        front=rear=0;
        queue[rear]=num;
    }

    else if(front==MAX-1 && front!=0)
    {
        cout<<"Enter the number:";cin>>num;
        rear=0;
        queue[rear]=num;
    }

    else
    {
        cout<<"Enter the number:";cin>>num;
        rear++;
        queue[rear]=num;
    }
}

int dequeue()
{
    int val;

    if(front==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        val=queue[front];

        if(front==rear)
        {
            front=rear=-1;
        }
        else if(front==MAX-1)
        {
            front=0;
        }
        else
        {
            front++;
        }
    }
    return val;
}

int peek()
{
    if(front==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        return(queue[front]);
    }
}

void display(int queue[])
{
    cout<<"\n";

    if(front==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        if(front!=-1 && rear!=-1)
        {
        if(front<=rear)
        {
            for(int i=front;i<=rear;i++)
            {
                cout<<queue[i]<<" ";
            }
        }
        else
        {
            for(int i=front;i<MAX;i++)
            {
                cout<<queue[i]<<" ";

                for(int i=0;i<+rear;i++)
                {
                    cout<<queue[i]<<" ";
                }
            }
        }
        }
    }
}

int main()
{
    int option,val;

    do
    {
      cout<<"1.Enqueue"<<endl;
      cout<<"2.Dequeue"<<endl;
      cout<<"3.Peek"<<endl;
      cout<<"4.Display"<<endl;
      
      cout<<"Enter the option:";cin>>option;

      switch(option)
      {
        case 1:
        enqueue();
        break;

        case 2:
        dequeue();
        break;

        case 3:
        val = peek();
        cout<<"Value is:"<<val<<endl;
        break;

        case 4:
        display(queue);
        cout<<endl;
        break;

        case 5:
        return 0;
      }
    }while(option!=5);

    return 0;
}


