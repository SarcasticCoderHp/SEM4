#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*front;
node*rear;

void enqueue()
{
    int num;
    node*ptr;

    cout<<"Enter the value:";cin>>num;
    ptr=new node();
    ptr->data=num;

    if(front==NULL)
    {
        front=ptr;
        rear=ptr;
        ptr->next=NULL;
    }
    else
    {
        rear->next=ptr;
        rear=ptr;
        ptr->next=NULL;
    }
}

void dequeue()
{
    node*ptr;

    if(front==NULL)
    {
        cout<<"Underflow";
    }
    else
    {
        ptr=front;
        front=front->next;
        free(ptr);
    }
}

void display()
{
    node*ptr;
    ptr=front;

    if(front==NULL)
    {
        cout<<"Empty queue";
    }
    else
    {
        while(ptr!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
    }
}

int peek()
{
    node*ptr;
    ptr=front;
    return ptr->data;
}

int main()
{
    int option,val;

    do
    {
      cout<<"1.Enqueue"<<endl;
      cout<<"2.Dequeue"<<endl;
      cout<<"3.Peek"<<endl;
      cout<<"4.Display"<<endl;
      
      cout<<"Enter the option:";cin>>option;

      switch(option)
      {
        case 1:
        enqueue();
        break;

        case 2:
        dequeue();
        break;

        case 3:
        val = peek();
        cout<<"Value is:"<<val<<endl;
        break;

        case 4:
        display();
        cout<<endl;
        break;

        case 5:
        return 0;
      }
    }while(option!=5);

    return 0;
}