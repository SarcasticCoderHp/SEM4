//DOUBLY LINKED LIST WITH ALL OPERATIONS//

#include<iostream>
using namespace std;

class node
{
    public:
      int data;
      node*next;
      node*prev;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    int num;
    node*new_node;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node = new node();
        new_node->data=num;
        new_node->prev=NULL;
        new_node->next=NULL;

        if(start==NULL)
        {
             start=new_node;    
             rear=new_node;
        }
        else
        {
          rear->next=new_node;
          new_node->prev=rear;
          rear=new_node;
        }
        cout<<"Enter the data:";cin>>num;
    }
    return start;
}

void display(node*start)
{
    node*ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty"<<endl;
    }
    else
    {
        while(ptr!=NULL)
        {
          cout<<ptr->data<<" ";
          ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }
}

int main()
{
    int option;

    do{

        cout<<"1.CREATE DOUBLY LIST"<<endl;
        cout<<"2.DISPLAY DOUBLY LIST"<<endl;
        cout<<"3.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            start=create(start);
            cout<<endl;
            cout<<"Linked list created"<<endl;
            break;

            case 2:
            display(start);
            cout<<endl;
            break;

            case 3:
            return 0;
        }
    }while(option!=3);

    return 0;
}