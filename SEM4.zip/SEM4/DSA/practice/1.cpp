#include<iostream>
using namespace std;

int main()
{
    int r,c;
    int count;

    cout<<"Enter the rows and columns:";cin>>r>>c;

    int mat[r][c];

    cout<<"Enter matrix elements:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>mat[i][j];
        }
    }

    cout<<endl;

    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    cout<<endl;

    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            if(mat[i][j]==0)
            count++;
        }
    }

    if(count>(r*c)/2)
    {
        cout<<"It is sparse matrix";
    }
    else
    {
        cout<<"It is Not a sparse matrix";
    }
    return 0;
}