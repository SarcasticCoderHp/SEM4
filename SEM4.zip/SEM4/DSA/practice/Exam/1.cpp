//LINEAR SEARCH

#include<iostream>
using namespace std;

int main()
{
    int array[100],num,size,pos=-1;

    cout<<"Enter the size of array:";cin>>size;

    cout<<"Enter array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>array[i];
    }

    cout<<"Enter the number to search:";cin>>num;
    for(int i=0;i<size;i++)
    {
        if(array[i]==num)
        {
            pos=i;
            break;
        }
    }

    if(pos!=-1)
    {
        cout<<"Number found at position:"<<pos+1<<endl;
    }
    else
    {
       cout<<"Not found";
    }
    return 0;
}