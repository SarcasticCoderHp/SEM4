#include<iostream>
#define size 5
using namespace std;

void insert_sort(int arr[],int n);

void insert_sort(int arr[],int n)
{
    int i,j,temp;

    for(i=1;i<n;i++)
    {
        temp=arr[i];
        j=i-1;

    while(temp<arr[j] && j>=0)
    {
        arr[j+1]=arr[j];
        j--;
    }
    arr[j+1]=temp;
    }
}

int main()
{
    int arr[size],n,i;

    cout<<"Enter the size of array:";cin>>n;

    cout<<"Enter the array elements:"<<endl;
    for(i=0;i<n;i++)
    {
        cin>>arr[i];
    }

     insert_sort(arr,n);

     cout<<"Sorted array is:"<<endl;
     for(i=0;i<n;i++)
     {
        cout<<arr[i]<<endl;
     }
}