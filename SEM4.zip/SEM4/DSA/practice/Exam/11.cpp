#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*left;
    node*right;
};

node*tree=NULL;

node*insert(node*tree,int val)
{
    node*ptr,*nodeptr,*parentptr;
    ptr=new node();
    ptr->data=val;
    ptr->left=NULL;
    ptr->right=NULL;

    if(tree==NULL)
    {
        tree=ptr;
        tree->left=NULL;
        tree->right==NULL;
    }
    else
    {
        parentptr=NULL;
        nodeptr=tree;

        while(nodeptr!=NULL)
        {
            parentptr=nodeptr;

            if(val<nodeptr->data)
            {
                nodeptr=nodeptr->left;
            }
            else
            {
                nodeptr=nodeptr->right;
            }
        }

        if(val<parentptr->data)
        {
            parentptr->left=ptr;
        }
        else
        {
            parentptr->right=ptr;
        }
    }
    return tree;
}

void inorder(node*tree)
{
    if(tree!=NULL)
    {
      inorder(tree->left);
      cout<<tree->data<<" "<<endl;
      inorder(tree->right);
    }
}

void preorder(node*tree)
{
    if(tree!=NULL)
    {
      cout<<tree->data<<" "<<endl;
      preorder(tree->left);
      preorder(tree->right);
    }
}

void postorder(node*tree)
{
    if(tree!=NULL)
    {
      postorder(tree->left);
      postorder(tree->right);
      cout<<tree->data<<" "<<endl;
    }
}

int search_ele(node*tree,int item,int flag)
{
    if(tree==NULL)
    {
        return flag;
    }
    
    while(tree!=NULL)
    {
        if(tree->data==item)
        {
            flag=1;
            return flag;
        }
        else
        {
            if(item<tree->data)
            {
                tree=tree->left;
            }
            else
            {
                tree=tree->right;
            }
        }
    }
    return flag;
}

int main()
{
    int option,val,flag,item;

    do
    {
        flag=0;

        cout<<"1.Insert"<<endl;
        cout<<"2.Inorder"<<endl;
        cout<<"3.Preorder"<<endl;
        cout<<"4.Postorder"<<endl;
        cout<<"5.Search"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
          case 1:
          cout<<"Enter the value:";cin>>val;
          tree=insert(tree,val);
          cout<<endl;
          break;

          case 2:
          inorder(tree);
          break;

          case 3:
          preorder(tree);
          break;

          case 4:
          postorder(tree);
          break;

          case 5:
          cout<<"Enter the element to search:";cin>>item;
          flag=search_ele(tree,item,flag);

          if(flag==0)
          {
            cout<<"Not found"<<endl;
          }
          else
          {
            cout<<"Element found"<<endl;
          }
          break;

          case 6:
          return 0;
        }
    }while(option!=6);

    return 0;
}



