//SELECTION SORT1

#include<iostream>
using namespace std;

int smallest(int a[],int n,int i)
{
    int small,pos,j;

    small=a[i];
    pos=i;

    for(j=i+1;j<5;j++)
    {
        if(a[j]<small)
        {
            small=a[j];
            pos=j;
        }
    }
    return pos;
}

int main()
{
  int a[5],pos,temp,i,j;

  cout<<"Enter 5 array elements:"<<endl;
  for(i=0;i<5;i++)
  {
    cin>>a[i];
  }

  for(i=0;i<5;i++)
  {
    pos=smallest(a,5,i);

    temp=a[i];
    a[i]=a[pos];
    a[pos]=temp;
  }

cout<<"Sorted array is:"<<endl;
for(int i=0;i<5;i++)
{
    cout<<a[i]<<endl;
}
}