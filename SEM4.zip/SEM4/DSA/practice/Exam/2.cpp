//BINARY SEARCH

#include<iostream>
using namespace std;

int main()
{
    int array[100],size,num,found=0;
    int beg,mid,end;

    cout<<"Enter the size of array:";cin>>size;

    cout<<"Enter array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>array[i];
    }

    cout<<"Enter no to search:";cin>>num;

    beg=0,end=num-1;

    while(beg<=end)
    {
        mid=(beg+end)/2;

        if(array[mid]==num)
        {
            cout<<"Number found at position:"<<mid+1<<endl;
            found=1;
            break;
        }
        else if(array[mid]>num)
        {
           end=mid-1;
        }
        else
        {
            beg=mid+1;
        }
    }

    if(found==0)
{
    cout<<"Not found";
}
return 0;

}