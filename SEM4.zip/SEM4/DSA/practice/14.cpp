#include<iostream>
using namespace std;

int main()
{
    int size,item,flag=0;
    int beg,mid,end;

    cout<<"Enter the size of array:";cin>>size;

    int arr[size];

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter the item to search:";cin>>item;
    beg=0,end=item-1;

    while(beg<=end)
    {
        mid=(beg+end)/2;

        if(arr[mid]==item)
        {
            flag=1;
            cout<<"Element found at position:"<<mid<<endl;
            break;
        }

        else if(arr[mid]>item)
        {
            end=mid-1;
        }
        else
        {
            beg=mid+1;
        }
    }

    if(flag==0)
    {
        cout<<"Element not found";
    }

    return 0;
}