//SINGLY LINKED LIST WITH ALL OPERATIONS//

#include<iostream>
using namespace std;

class node
{
  public:
  int data;
  node*next;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
  node*new_node;
  int num;

  cout<<"Enter -1 to end"<<endl;
  cout<<"Enter the data:";cin>>num;

  while(num!=-1)
  {
    new_node = new node();
    new_node->data=num;

  if(start==NULL)
  {
    new_node->next=NULL;
    start=new_node;
    rear=new_node;
  }
  else
  {
    rear->next=new_node;
    new_node->next=NULL;
    rear=new_node;
  }
  cout<<"Enter the data:";cin>>num;
  }
  return start;
}

void display(node*start)
{
  node*ptr;
  ptr=start;

  if(start==NULL)
  {
    cout<<"Linked list is empty"<<endl;
  }
  else
  {
    while(ptr->next!=NULL)
    {
      cout<<ptr->data<<" ";
      ptr=ptr->next;
    }
    cout<<ptr->data<<" ";
    cout<<endl;
  }
}

node*insert_begin(node*start)
{
  node*new_node;
  int num;

  cout<<"Enter the data:";cin>>num;
  new_node = new node();
 
  new_node->data=num;
  new_node->next=start;
  start=new_node;
  display(start);
  return start;
  cout<<endl;
}

node*insert_end(node*start)
{
  node*new_node,*ptr;
  int num;

  cout<<"Enter the data:";cin>>num;
  new_node = new node();

  new_node->data=num;
  ptr=start;

  while(ptr->next!=NULL)
  {
    ptr=ptr->next;
  }
   ptr->next=new_node;
    new_node->next=NULL;
    display(start);
    return start;
}

node*delete_begin(node*start)
{
  node*ptr;

  if(start==NULL)
  {
    cout<<"Linked list is empty";
  }
  else
  {
    ptr=start;
    start=start->next;
    free(ptr);
  }
  display(start);
  return start;
}

node*delete_end(node*start)
{
  node*ptr,*preptr;
  ptr=start;

  if(start==NULL)
  {
    cout<<"Linked list is empty";
  }
  else
  {
    while(ptr->next!=NULL)
    {
      preptr=ptr;
      ptr=ptr->next;
    }
    preptr->next=NULL;
    free(ptr);
  }
  display(start);
  return start;
}

node*insert_after(node*start)
{
  node*new_node,*ptr,*preptr;
  int num,val;

  cout<<"Enter the data:";cin>>num;
  cout<<"Enter the value to insert after:";cin>>val;
  new_node = new node();

  new_node->data=num;
  ptr=start;
  preptr=start;

  while(preptr!=NULL && preptr->data!=val)
  {
    preptr=ptr;
    ptr=ptr->next;
  }

  if(preptr==NULL)
  {
    cout<<"value not found";
  }
  else
  {
  new_node->next=ptr;
  preptr->next=new_node;
  }
  display(start);
  return start;
}

node* delete_after(node* start)
{
  node* ptr, * preptr;
  int val;

  cout << "Enter the value:"; cin >> val;
  ptr = start;
  preptr = start;

  if (start == NULL)
  {
    cout << "Linked list is empty";
  }
  else
  {
    while (preptr != NULL && preptr->data != val)
    {
      preptr = ptr;
      if (ptr != NULL) 
        ptr = ptr->next;
    }

    if (preptr != NULL && ptr != NULL && ptr->next != NULL)
    {
      preptr->next = ptr->next;
    }
    else
    {
      cout << "Value not found or no node to delete after." << endl;
    }
  }

  display(start);
  return start;
}

int main()
{
  int option;

do{
      cout<<"1.CREATE LINKED LIST"<<endl;
      cout<<"2.DISPLAY LINKED LIST"<<endl;
      cout<<"3.INSERT AT BEGIN"<<endl;
      cout<<"4.INSERT AT END"<<endl;
      cout<<"5.DELETE AT BEGIN"<<endl;
      cout<<"6.DELETE AT END"<<endl;
      cout<<"7.INSERT AT AFTER"<<endl;
      cout<<"8.DELETE AT AFTER"<<endl;
      cout<<"9.EXIT"<<endl;

      cout<<"Enter the option:";cin>>option;

      cout<<endl;

      switch(option)
      {
        case 1:
        start = create(start);
        cout<<"Linked list created"<<endl;
        cout<<endl;
        break;

        case 2:
        display(start);
        cout<<endl;
        break;

        case 3:
        start = insert_begin(start);
        cout<<endl;
        break;

        case 4:
        start = insert_end(start);
        cout<<endl;
        break;

        case 5:
        start = delete_begin(start);
        cout<<endl;
        break;

        case 6:
        start = delete_end(start);
        cout<<endl;
        break;

        case 7:
        start = insert_after(start);
        cout<<endl;
        break;

        case 8:
        start = delete_after(start);
        cout<<endl;
        break;

        case 9:
        return 0;
      }
 }while(option!=3);
  
  return 0;

}