#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
    node*prev;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node=new node();
        new_node->data=num;

        if(start==NULL)
        {
            start=new_node;
            new_node->next=NULL;
            new_node->prev=NULL;
            rear=new_node;
        }
        else
        {
            rear->next=new_node;
            new_node->prev=rear;
            rear=new_node;
        }
        cout<<"Enter the data:";cin>>num;
    }
    return start;
}

void display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }
}

node*rev_disp(node*start)
{
    node*ptr;
    ptr=start;

    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }
    while(ptr->prev!=NULL)
    {
        cout<<ptr->data<<" ";
        ptr=ptr->prev;
    }
    cout<<ptr->data;
    cout<<endl;

    return start;
}

node*insert_begin(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node=new node();
    new_node->data=num;

    new_node->next=start;
    new_node->prev=NULL;
    start->prev=new_node;
    start=new_node;

    display(start);
    return start;
}

node*insert_end(node*start)
{
    node*new_node,*ptr;  ptr=start;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }

    ptr->next=new_node;
    new_node->next=NULL;
    new_node->prev=ptr;

    display(start);
    return start;
}

node*delete_begin(node*start)
{
    node*ptr;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
       ptr=start;
       start=start->next;
       start->prev=NULL;
       free(ptr);
    }

    display(start);
    return start;
}

node*delete_end(node*start)
{
    node*ptr,*preptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            preptr=ptr;
            ptr=ptr->next;
        }

        preptr->next=NULL;
        free(ptr);
    }

    display(start);
    return start;
}

node*insert_after(node*start)
{
    node*ptr,*new_node;
    ptr=start;
    int num,val;

    cout<<"Enter the data:";cin>>num;
    cout<<"Enter the value to insert after:";cin>>val;

    new_node=new node();
    new_node->data=num;

    while(ptr->data!=val)
    {
        ptr=ptr->next;
    }

    new_node->prev=ptr;
    new_node->next=ptr->next;
    ptr->next->prev=new_node;
    ptr->next=new_node;

    display(start);
    return start;
}

node*delete_mid(node*start)
{
    node*ptr,*preptr;
    int val; ptr=start;

    cout<<"Enter the value to delete:";cin>>val;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
        while(ptr->data!=val)
        {
            ptr=ptr->next;
        }
        preptr=ptr->prev;
        preptr->next=ptr->next;
        ptr->next->prev=preptr;
        free(ptr);
    }
    display(start);
    return start;
}

void count(node*start)
{
    node*ptr;
    ptr=start;

    int count=0;

    while(ptr!=NULL)
    {
        count++;
        ptr=ptr->next;
    }
    cout<<"Total no of nodes:"<<count<<endl;
}

void evenodd(node*start)
{
    node*ptr;
    ptr=start;

    int evenc=0;
    int oddc=0;

    while(ptr!=NULL)
    {
        if(ptr->data%2==0)
        {
            evenc++;
        }
        else
        {
            oddc++;
        }
        ptr=ptr->next;
    }
    cout<<"Total even nodes:"<<evenc<<endl;
    cout<<"Total odd nodes:"<<oddc<<endl;
}

void search(node*start)
{
    node*ptr;
    ptr=start;
    
    int element;
    bool isFound=false;

    cout<<"Enter the value to search:";cin>>element;

    while(ptr!=NULL)
    {
    if(ptr->data==element)
    {
        isFound=true;
        break;
    }
    ptr=ptr->next;
    }
    
    if(isFound)
    {
        cout<<"Element found in linked list"<<endl;
    }
    else
    {
        cout<<"Element not found"<<endl;
    }
}

int main()
{
    int option;

    do
    {
       cout<<"1.CREATE"<<endl;
       cout<<"2.DISPLAY"<<endl;
       cout<<"3.REVERSE"<<endl;
       cout<<"4.INSERT BEGIN"<<endl;
       cout<<"5.INSERT END"<<endl;
       cout<<"6.DELETE BEGIN"<<endl;
       cout<<"7.DELETE END"<<endl;
       cout<<"8.INSERT AFTER"<<endl;
       cout<<"9.DELETE MIDDLE"<<endl;
       cout<<"10.COUNT NODES"<<endl;
       cout<<"11.COUNT EVEN ODD NODES"<<endl;
       cout<<"12.SEARCH AN ELEMENT"<<endl;
       cout<<"13.EXIT"<<endl;

       cout<<"Enter the option";cin>>option;

       switch(option)
       {
           case 1:
           start=create(start);
           cout<<"Created"<<endl;
           break;

           case 2:
           display(start);
           cout<<endl;
           break;

           case 3:
           start=rev_disp(start);
           cout<<endl;
           break;

           case 4:
           start=insert_begin(start);
           cout<<endl;
           break;

           case 5:
           start=insert_end(start);
           cout<<endl;
           break;

           case 6:
           start=delete_begin(start);
           cout<<endl;
           break;

           case 7:
           start=delete_end(start);
           cout<<endl;
           break;

           case 8:
           start=insert_after(start);
           cout<<endl;
           break;

           case 9:
           start=delete_mid(start);
           cout<<endl;
           break;

           case 10:
           count(start);
           cout<<endl;
           break;

           case 11:
           evenodd(start);
           cout<<endl;
           break;

           case 12:
           search(start);
           cout<<endl;
           break;

           case 13:
           return 0;
       }

    } while (option!=13);
    return 0;
}