#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    int num;
    node*new_node;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node = new node();
        new_node->data=num;

        if(start==NULL)
        {
            new_node->next=NULL;
            start=new_node;
            rear=new_node;
        }
        else
        {
            rear->next=new_node;
            new_node->next=NULL;
            rear=new_node;
        }
        cout<<"Enter the data:";cin>>num;
    }
    return start;
}

void display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }
}

node*insert_beg(node*start)
{
    int num;
    node*new_node;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    new_node->next=start;
    start=new_node;

    display(start);
    return start;
}

node*delete_beg(node*start)
{
    node*ptr;

    if(start==NULL)
    {
        cout<<"Linked list is empty";
    }
    else
    {
        ptr=start;
        start=start->next;
        free(ptr);
    }
    display(start);
    return start;
}

int main()
{
    int option;

    do
    {
        cout<<"1.CREATE"<<endl;
        cout<<"2.DISPLAY"<<endl;
        cout<<"3.INSERT BEGIN"<<endl;
        cout<<"4.DELETE BEGIN"<<endl;
        cout<<"5.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            start=create(start);
            cout<<endl;
            break;

            case 2:
            display(start);
            cout<<endl;
            break;

            case 3:
            start=insert_beg(start);
            cout<<endl;
            break;

            case 4:
            start=delete_beg(start);
            break;

            case 5:
            return 0;
        }
    }while(option!=5);
    return 0;
}