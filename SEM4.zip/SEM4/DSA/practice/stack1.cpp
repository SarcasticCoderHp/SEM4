#include<iostream>
using namespace std;

int stack[100],n=100,top=-1;

void push(int val)
{
    if(top>=n-1)
    {
        cout<<"Stack overflow";
    }
    else
    {
        top++;
        stack[top]=val;
    }
}

void pop()
{
    if(top<=-1)
    {
        cout<<"Stack underflow";
    }
    else
    {
        cout<<"Popper element is:"<<stack[top]<<endl;
        top--;
    }
}

void display()
{
    if(top>=0)
    {
        cout<<"Stack elements are:"<<endl;
        for(int i=top;i>=0;i--)
        {
            cout<<stack[i]<<" ";
            cout<<endl;
        }
    }
    else
    {
        cout<<"Stack is empty";
    }
}

int main()
{
    int option,val;

    cout<<"1.Push"<<endl;
    cout<<"2.Pop"<<endl;
    cout<<"3.Sisplay"<<endl;
    cout<<"4.Exit"<<endl;

do{

    cout<<"Enter the choice:";cin>>option;

    switch(option)
    {
        case 1:
        cout<<"Enter the value to push:";cin>>val;
        push(val);
        break;

        case 2:
        pop();
        break;

        case 3:
        display();
        break;

        case 4:
        return 0;

        default:
        cout<<"Invalid choice";
    }
}while(option!=4);
return 0;
}