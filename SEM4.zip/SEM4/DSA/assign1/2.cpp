#include<iostream>
using namespace std;

    void array()
    {
        int size;
        cout<<"Enter the size:";cin>>size;

         int arr[size];

        cout<<"Enter the array elements:";
        for(int i=0;i<size;i++)
        {
            cin>>arr[i];
        }
           cout<<"The array is:"<<endl;
        for(int i=0;i<size;i++)
        {
            cout<<arr[i]<<" ";
        }
    }


int main()
{
  array();
}