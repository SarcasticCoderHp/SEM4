#include<iostream>
using namespace std;

int main()
{
    int*arr=new int[5];
    int sum=0;

    cout<<"Enter array elements:";
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }
    
    for(int i=0;i<5;i++)
    {
        sum=sum+arr[i];
    }

    cout<<"Sum of elements:"<<sum<<endl;

    return 0;
}