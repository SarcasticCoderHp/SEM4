#include<iostream>
using namespace std;

int main()
{
    int r,c;
    int count;

    cout<<"Enter the rows and columns:";cin>>r>>c;

    int mat[r][c];

    cout<<"Enter the matrix elements:";
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>mat[i][j];
        }
    }

    cout<<"The matrix is:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            if(mat[i][j]==0)
            count++;
        }
    }

    if(count>(r*c)/2)
    {
        cout<<"Sparse matrix";
    }
    else
    {
        cout<<"Not a sparse matrix";
    }
    return 0;}