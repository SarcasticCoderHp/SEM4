#include<iostream>
using namespace std;

int main()
{
    int size;

    cout<<"Enter the size:";cin>>size;

    int mat[size][size];

    cout<<"Enter array elements:";
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            cin>>mat[i][j];
        }
    }
    cout<<"The array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    bool isLowerTriangle=true;
    for(int i=0;i<size;i++)
    {
        for(int j=i+1;j<size;j++)
        {
          if(mat[i][j]!=0)
          {
            isLowerTriangle=false;
            break;
          }
        }
    }
    
    if(isLowerTriangle)
    {
        cout<<"Lower Triangular matrix";
    }
    else
    {
        cout<<"Not Lower Triangular matrix";
    }

    cout<<endl;

   cout<<"Lower triangular matrix representation:"<<endl;
   for(int i=0;i<size;i++)
   {
    for(int j=0;j<size;j++)
    {
        if(i<j)
        {
            cout<<"0"<<" ";
        }
        else
        cout<<mat[i][j]<<" ";
    }
    cout<<endl;
   }

    return 0;
}
