#include<iostream>
using namespace std;

class Student
{
    public:
    int no;
    string name;
    string address;

void get()
{
    cout<<"Enter the no:";cin>>no;
    cout<<"Enter the name:";cin>>name;
    cout<<"Enter the address:";cin>>address;
}

void display()
{
    cout<<"No:"<<no<<endl;
    cout<<"Name:"<<name<<endl;
    cout<<"Address:"<<address<<endl;
}
};

int main()
{
    Student obj1,obj2,obj3;

    obj1.get();
    obj1.display();

    cout<<"================="<<endl;

    obj2.get();
    obj2.display();

    cout<<"================="<<endl;

    obj3.get();
    obj3.display();

    return 0;
}