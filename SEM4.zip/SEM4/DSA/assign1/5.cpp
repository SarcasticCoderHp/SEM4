#include<iostream>
using namespace std;

int main()
{
    int size;

    cout<<"Enter the size:";cin>>size;

    int arr[size];

    cout<<"Enter the array elements:";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"The array is:"<<endl;
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<endl;
    }
   
    cout<<"Array in reverse order:"<<endl;

    for(int i=size-1;i>=0;i--)
    {
        cout<<arr[i]<<endl;
    }
    return 0;
}