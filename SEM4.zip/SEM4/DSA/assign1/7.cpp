#include<iostream>
using namespace std;

int main()
{
    int size;

    cout<<"Enter the size:";cin>>size;

    int mat[size][size];

    cout<<"Enter array elements:";
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            cin>>mat[i][j];
        }
    }
    cout<<"The array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    bool ans=true;
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            if(i!=j && mat[i][j]!=0)
            {
                ans=false;
                break;
            }
        }
    }

    if(ans)
    {
        cout<<"Diagonal matrix";
    }
    else
    {
        cout<<"Not Diagonal matrix";
    }

    return 0;
}