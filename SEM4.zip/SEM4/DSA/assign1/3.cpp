#include<iostream>
using namespace std;

void array()
{
    int r,c;
    cout<<"Enter the rows and columns:";cin>>r>>c;

    int arr[r][c];

    cout<<"Enter array elements:";
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>arr[i][j];
        }
    }

    cout<<"The array is:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    array();
}