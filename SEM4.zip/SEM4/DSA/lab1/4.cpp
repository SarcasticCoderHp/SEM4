//upper triangular

#include<iostream>
using namespace std;

int main()
{
    int n;

    cout<<"Enter the size of matrix:";cin>>n;

    int mat[n][n];

    cout<<"Enter the matrix elements:"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            cin>>mat[i][j];
        }
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }
   
     bool isUpperTriangular=true;

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if((i>j) && (mat[i][j]!=0))
            {
                isUpperTriangular=false;
                break;
            }
        }
    }

    if(isUpperTriangular)
    {
        cout<<"It is upper triangular matrix";
    }
    else
    {
        cout<<"It is not upper triangular matrix";
    }

}