#include<iostream>
using namespace std;

int main()
{
    int r,c;
    int count;

    cout<<"Enter the rows and columns:";cin>>r>>c;

    int mat[r][c];

    cout<<"Enter matrix elements:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>mat[i][j];
        }
    }

    cout<<endl;
     
     int size=0;

     for(int i=0;i<r;i++)
     {
        for(int j=0;j<c;j++)
        {
            if(mat[i][j]!=0)
            {
                size++;
            }
        }
     }
     int matrix[3][size];
     int k=0;

     for(int i=0;i<r;i++)
     {
        for(int j=0;j<c;j++)
        {
            if(mat[i][j]!=0)
            {
                matrix[0][k]=i;
                matrix[1][k]=j;
                matrix[2][k]=mat[i][j];
                k++;
            }
        }
     }

     for(int i=0;i<3;i++)
     {
        for(int j=0;j<size;j++)
        {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
     }
    return 0;
}