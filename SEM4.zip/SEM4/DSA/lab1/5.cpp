//lower triangular//upper triangular

#include<iostream>
using namespace std;

int main()
{
    int n;

    cout<<"Enter the size of matrix:";cin>>n;

    int mat[n][n];

    cout<<"Enter the matrix elements:"<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            cin>>mat[i][j];
        }
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }
   
     bool isLowerTriangular=true;

    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(mat[i][j]!=0)
            {
                isLowerTriangular=false;
                break;
            }
        }
    }

    if(isLowerTriangular)
    {
        cout<<"It is lower triangular matrix";
    }
    else
    {
        cout<<"It is not lower triangular matrix";
    }

}