#include<iostream>
using namespace std;

int main()
{
    int r,c;

    cout<<"Enter the rows and columns:";cin>>r>>c;

     int mat[r][c];
   
    if(r==c)
    {
        cout<<"It is square matrix"<<endl;
    }
    else
    {
        cout<<"It is not square matrix"<<endl;
        return 0;
    }

    cout<<"Enter matrix elements:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>mat[i][j];
        }
    }

     cout<<"Matix is:"<<endl;
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<mat[i][j]<<" ";
        }
        cout<<endl;
    }

    bool ans = true;

    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            if( i!=j && mat[i][j]!=0)
            {
                ans=false;
            }
        }
    }
    if(ans)
    {
        cout<<"Diagonal matrix";
    }
    else
    {
        cout<<"Not diagonal matrix";
    }
    return 0;
}