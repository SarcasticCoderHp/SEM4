#include<iostream>
using namespace std;

int main()
{
    int size,val,pos=-1;
    int arr[5];

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter the value to search:";cin>>val;

    for(int i=0;i<5;i++)
    {
        if(arr[i]==val)
        {
            pos=i;
            break;
        }
    }

    if(pos!=-1)
    {
        cout<<"Element found at index:"<<pos<<endl;
    }
    else
    {
        cout<<"Element not found"<<endl;
    }
}