#include<iostream>
using namespace std;

class node
{
  public:
  int data;
  node*next;
  node*prev;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter -1 to end"<<endl;
    cout<<"Enter the data:";cin>>num;

    while(num!=-1)
    {
        new_node=new node();
        new_node->data=num;

        if(start==NULL)
        {
            new_node->next=NULL;
            start=new_node;
            rear=new_node;
            new_node->prev=NULL;
        }
        else
        {
            rear->next=new_node;
            new_node->prev=rear;
            rear=new_node;
        }
        cout<<"Enter the data:";cin>>num;
    }
    return start;
}

void display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }

}

node*reverse(node*start)
{
    node*ptr;
    ptr=start;

        while(ptr->next!=NULL)
        {
            ptr=ptr->next;
        }

        while(ptr->prev!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->prev;
        }
        cout<<ptr->data;
        cout<<endl;

        display(start);
        return start;
}

node*insert_beg(node*start)
{
    node*new_node;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    new_node->next=start;
    new_node->prev=NULL;
    start=new_node;

    display(start);
    return start;
}

node*insert_end(node*start)
{
    node*new_node,*ptr;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node=new node();
    new_node->data=num;

    ptr=start;

    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }

    ptr->next=new_node;
    new_node->prev=ptr;
    new_node->next=NULL;

    display(start);
    return start;
}

node*delete_beg(node*start)
{
    node*ptr;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
        ptr=start;
        start=start->next;
        start->prev=NULL;
        free(ptr);
    }
    display(start);
    return start;
}

node*delete_end(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
        while(ptr->next!=NULL)
        {
            ptr=ptr->next;
        }

        ptr->prev->next=NULL;
        free(ptr);
    }
        display(start);
        return start;
}

node*delete_mid(node*start)
{
  node*ptr,*preptr;
  int val;

  cout<<"Enter the value to delete:";cin>>val;

  ptr=start;

  if(start==NULL)
  {
    cout<<"Empty";
  }
  else
  {
    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }

    preptr=ptr->prev;
    preptr->next=ptr->next;
    ptr->next->prev=preptr;
    free(ptr);
  }
  display(start);
  return start;
}

node*insert_after(node*start)
{
    node*new_node,*ptr,*preptr;
    int num,val;

    cout<<"Enter the data:";cin>>num;
    cout<<"Enter the value to insertt after:";cin>>val;

    new_node=new node();
    new_node->data=num;

    ptr=start;
    preptr=start;

    while(preptr->next!=NULL && preptr->data!=val)
    {
        preptr=ptr;
        ptr=ptr->next;
    }

    if(preptr==NULL)
    {
        cout<<"Value not found";
    }
    else
    {
        new_node->next=ptr;
        preptr->next=new_node;
    }

    display(start);
    return start;
}

int main()
{
    int option;

    do 
    {
        cout<<"1.Create"<<endl;
        cout<<"2.Display"<<endl;
        cout<<"3.Insert begin"<<endl;
        cout<<"4.Insert end"<<endl;
        cout<<"5.Delete begin"<<endl;
        cout<<"6.Delete end"<<endl;
        cout<<"7.Insert after"<<endl;
        cout<<"8.Delete mid"<<endl;
        cout<<"9.Reverse"<<endl;
        cout<<"10.Exit"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            start=create(start);
            cout<<endl;
            break;

            case 2:
            display(start);
            cout<<endl;
            break;

            case 3:
            start=insert_beg(start);
            cout<<endl;
            break;

            case 4:
            start=insert_end(start);
            cout<<endl;
            break;

            case 5:
            start=delete_beg(start);
            cout<<endl;
            break;

            case 6:
            start=delete_end(start);
            cout<<endl;
            break;

            case 7:
            start=insert_after(start);
            cout<<endl;
            break;
            
            case 8:
            start=delete_mid(start);
            cout<<endl;
            break;

            case 9:
            start=reverse(start);
            cout<<endl;
            break;

            case 10:
            return 0;
        }
    }while(option!=10);

    return 0;
}