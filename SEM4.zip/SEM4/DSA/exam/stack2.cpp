#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*top;

node*push(node*top)
{
    node*new_node;
    int num;

    cout<<"Enter the value to push:";cin>>num;
    new_node=new node();
    new_node->data=num;

    if(top==NULL)
    {
        new_node->next=NULL;
        top=new_node;
    }
    else
    {
        new_node->next=top;
        top=new_node;
    }
    return top;
}

node*pop(node*top)
{
    node*ptr;

    if(top==NULL)
    {
        cout<<"Underflow"<<endl;
    }
    else
    {
        ptr=top;
        top=top->next;
        free(ptr);
    }
    return top;
}

node*display(node*top)
{
    node*ptr=top;

    if(top==NULL)
    {
        cout<<"Underflow";
    }
    else
    {
      while(ptr!=NULL)
      {
        cout<<ptr->data<<" ";
        ptr=ptr->next;
      }
    }
    return top;
}

int peek(node*top)
{
    return top->data;
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.PUSH"<<endl;
        cout<<"2.POP"<<endl;
        cout<<"3.DISPLAY"<<endl;
        cout<<"4.PEEK"<<endl;
        cout<<"5.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            top=push(top);
            cout<<endl;
            break;

            case 2:
            top=pop(top);
            cout<<endl;
            break;

            case 3:
            top=display(top);
            cout<<endl;
            break;

            case 4:
            val=peek(top);
            cout<<"Value is:"<<val<<endl;
            break;

            case 5:
            return 0;
        }
    }while(option!=5);
    return 0;
}