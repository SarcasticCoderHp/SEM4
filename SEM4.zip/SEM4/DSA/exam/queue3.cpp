#include<iostream>
#define MAX 10
using namespace std;

int queue[MAX],front=-1,rear=-1;

void enque()
{
    int num;

    if((front==rear+1) || (front==0 && rear==MAX-1))
    {
       cout<<"Overflow";
    }
    else if(front==-1 && rear==-1)
    {
        cout<<"Enter the data:";cin>>num;
        front=rear=0;
        queue[rear]=num;
    }
    else if(rear==MAX-1 && front!=0)
    {
        cout<<"Enter the data:";cin>>num;
        rear=0;
        queue[rear]=num;
    }
    else
    {
        cout<<"Enter the data:";cin>>num;
        rear++;
        queue[rear]=num;
    }
}

int deque()
{
    int val;

    if(front==-1)
    {
        cout<<"Underflow";
    }
    else if(front==MAX-1)
    {
        front=0;
    }
    else
    {
        front++;
    }
    return val;
}

int peek()
{
     return queue[front];
}

void display()
{
    if(front==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        if(front!=-1 && rear!=-1)
        {
            if(front<=rear)
            {
                for(int i=front;i<=rear;i++)
                {
                    cout<<queue[i]<<" ";
                }
            }
        }
    }
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.Enque"<<endl;
        cout<<"2.Deque"<<endl;
        cout<<"3.Peek"<<endl;
        cout<<"4.Display"<<endl;
        cout<<"5.Exit"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            enque();
            cout<<endl;
            break;

            case 2:
            val=deque();
            cout<<"Deleted value is:"<<val<<endl;
            break;

            case 3:
            val=peek();
            cout<<"Value is:"<<val;
            cout<<endl;
            break;

            case 4:
            display();
            cout<<endl;
            break;

            case 5:
            return 0;
        }
    }while(option!=5);

    return 0;
}