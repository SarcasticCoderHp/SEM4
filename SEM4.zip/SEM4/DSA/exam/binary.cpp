#include<iostream>
using namespace std;

int main()
{
    int size;
    cout<<"Enter size of array:";cin>>size;

    int arr[size],val,flag=0;
    int beg,mid,end;

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter the value to search:";cin>>val;
    beg=0,end=val-1;

    while(beg<=end)
    {
         mid=(beg+end)/2;

        if(arr[mid]==val)
        {
            cout<<"Element found at index:"<<mid<<endl;
            flag=1;
            break;
        }

        else if(arr[mid]>val)
        {
            end=mid-1;
        }
        else
        {
            beg=mid+1;
        }
    }

    if(flag==0)
    {
        cout<<"Element not found"<<endl;
    }

    return 0;
}