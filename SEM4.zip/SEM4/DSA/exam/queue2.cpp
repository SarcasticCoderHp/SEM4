#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*front;
node*rear;

void enque()
{
    int num;
    node*new_node;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    if(front==NULL)
    {
        new_node->next=NULL;
        front=new_node;
        rear=new_node;
    }
    else
    {
        rear->next=new_node;
        new_node->next=NULL;
        rear=new_node;
    }
}

void deque()
{
    node*ptr;

    if(front==NULL)
    {
        cout<<"Underflow";
    }
    else
    {
        ptr=front;
        front=front->next;
        free(ptr);
    }
}

void display()
{
    node*ptr=front;

    if(front==NULL)
    {
        cout<<"Underflow";
    }
    else
    {
        while(ptr!=NULL)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
    }
}

void evenCount()
{
    int evencount=0;
    node*ptr;
    ptr=front;

    if(front==NULL)
    {
        cout<<"Underflow"<<endl;
    }
    else
    {
        do
        {
            if(ptr->data%2==0)
            {
                cout<<ptr->data<<" ";
                evencount++;
            }
            ptr=ptr->next;

        }while(ptr!=NULL);
    }

    cout<<"Even nodes are:"<<evencount<<endl;
}

int peek()
{
    node*ptr=front;
    return ptr->data;
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.Enque"<<endl;
        cout<<"2.Deque"<<endl;
        cout<<"3.Peek"<<endl;
        cout<<"4.Display"<<endl;
        cout<<"5.Even nodes"<<endl;
        cout<<"6.Exit"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            enque();
            cout<<endl;
            break;

            case 2:
            deque();
            break;

            case 3:
            val=peek();
            cout<<"Value is:"<<val;
            cout<<endl;
            break;

            case 4:
            display();
            cout<<endl;
            break;

            case 5:
            evenCount();
            cout<<endl;
            break;

            case 6:
            return 0;
        }
    }while(option!=6);

    return 0;
}