#include<iostream>
using namespace std;

int stack[100],n=100,top=-1;

void push(int val)
{
    if(top>n-1)
    {
        cout<<"Overflow";
    }
    else
    {
        top++;
        stack[top]=val;
    }
}

void pop()
{
    if(top==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        cout<<"Popped element is:"<<stack[top]<<endl;
        top--;
    }
}

int peek()
{
    return (stack[top]);
}

void display()
{
    if(top==-1)
    {
        cout<<"Underflow";
    }
    else
    {
        for(int i=top;i>=0;i--)
        {
            cout<<stack[i]<<endl;
        }
    }
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.PUSH"<<endl;
        cout<<"2.POP"<<endl;
        cout<<"3.PEEK"<<endl;
        cout<<"4.DISPLAY"<<endl;
        cout<<"5.EXIT"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            cout<<"Enter the value to push:";cin>>val;
            push(val);
            cout<<endl;
            break;

            case 2:
            pop();
            break;

            case 3:
            val=peek();
            cout<<"Value is:"<<val<<endl;
            break;

            case 4:
            display();
            cout<<endl;
            break;

            case 5:
            return 0;

        }
    }while(option!=5);

    return 0;
}
