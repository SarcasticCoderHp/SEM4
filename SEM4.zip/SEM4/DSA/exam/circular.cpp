#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node*next;
};

node*start=NULL;
node*rear=NULL;

node*create(node*start)
{
   node*new_node;
   int num;

   cout<<"Enter -1 to end"<<endl;
   cout<<"Enter the data:";cin>>num;

   while(num!=-1)
   {
    new_node = new node();
    new_node->data=num;

    if(start==NULL)
    {
        new_node->next=start;
        start=new_node;
        rear=new_node;
    }
    else
    {
        rear->next=new_node;
        new_node->next=start;
        rear=new_node;
    }
    cout<<"Enter the data:";cin>>num;
   }
   return start;
}

node*display(node*start)
{
    node*ptr;
    ptr=start;

    if(start==NULL)
    {
        cout<<"Empty";
    }
    else
    {
        while(ptr->next!=start)
        {
            cout<<ptr->data<<" ";
            ptr=ptr->next;
        }
        cout<<ptr->data;
        cout<<endl;
    }
    return start;
}

node*insert_beg(node*start)
{
    node*new_node,*ptr;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node = new node();
    new_node->data=num;

    ptr=start;

    while(ptr->next!=start)
    {
        ptr=ptr->next;
    }

    ptr->next=new_node;
    new_node->next=start;
    start=new_node;

    display(start);
    return start;
}

node*insert_end(node*start)
{
    node*new_node,*ptr;
    int num;

    cout<<"Enter the data:";cin>>num;
    new_node=new node();
    new_node->data=num;
    new_node->next=start;
    

    ptr=start;
    while(ptr->next!=start)
    {
        ptr=ptr->next;
    }
    ptr->next=new_node;

    display(start);
    return start;
}

node*delete_beg(node*start)
{
    node*ptr,*temp;
    ptr=start;

    while(ptr->next!=start)
    {
        ptr=ptr->next;
    }

    ptr->next=start->next;
    temp=start;
    free(temp);
    start=ptr->next;

    display(start);
    return start;
}

node*delete_end(node*start)
{
    node*ptr,*preptr;
    ptr=start;

    while(ptr->next!=start)
    {
        preptr=ptr;
        ptr=ptr->next;
    }

    preptr->next=start;
    free(ptr);

    display(start);
    return start;
}

void even(node*start)
{
    node*ptr;
    ptr=start;

    int evenCount = 0; 

    do {
        if(ptr->data % 2 == 0) {
            evenCount++;
        }
        ptr = ptr->next;
    } while(ptr != start);

    cout << "Even nodes are: " << evenCount << endl;
}

void odd(node*start)
{
    node*ptr;
    ptr=start;

    int oddCount = 0; 

    do {
        if(ptr->data % 2 != 0) {
            oddCount++;
        }
        ptr = ptr->next;
    } while(ptr != start);

    cout << "Odd nodes are: " << oddCount << endl;
}

void total(node* start)
{
    node* ptr = start;
    int nodeCount = 0;

    if (start != NULL) {
        do {
            nodeCount++;
            ptr = ptr->next;
        } while (ptr != start);
    }

    cout<<"Total nodes count:"<<nodeCount<<endl;;
}


int main()
{
   int option;

   do
   {
     cout<<"1.Create"<<endl;
     cout<<"2.Display"<<endl;
     cout<<"3.Insert begin"<<endl;
     cout<<"4.Insert end"<<endl;
     cout<<"5.Delete begin"<<endl;
     cout<<"6.Delete end"<<endl;
     cout<<"7.Even nodes"<<endl;
     cout<<"8.Odd nodes"<<endl;
     cout<<"9.Total nodes"<<endl;
     cout<<"10.Exit"<<endl;

     cout<<"Enter the option:";cin>>option;

     switch(option)
     {
        case 1:
        start=create(start);
        cout<<endl;
        break;

        case 2:
        display(start);
        cout<<endl;
        break;

        case 3:
        start=insert_beg(start);
        cout<<endl;
        break;

        case 4:
        start=insert_end(start);
        cout<<endl;
        break;

        case 5:
        start=delete_beg(start);
        cout<<endl;
        break;

        case 6:
        start=delete_end(start);
        cout<<endl;
        break;

        case 7:
        even(start);
        cout<<endl;
        break;

        case 8:
        odd(start);
        cout<<endl;
        break;

        case 9:
        total(start);
        cout<<endl;
        break;

        case 10:
        return 0;
     }
   }while(option!=10);

   return 0;
}