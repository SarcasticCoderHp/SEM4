#include<iostream>
using namespace std;

int smallest(int arr[],int n,int i)
{
    int j,pos,small;

    small=arr[i];
    pos=i;

    for(j=i+1;j<n;j++)
    {
        if(arr[j]<small)
        {
            small=arr[j];
            pos=j;
        }
    }
    return pos;
}

int main()
{
    int arr[5],pos,i,j,temp;

    cout<<"Enter the array elements:"<<endl;
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }

    for(i=0;i<4;i++)
    {
        pos=smallest(arr,5,i);

        temp=arr[i];
        arr[i]=arr[pos];
        arr[pos]=temp;
    }

    cout<<"Sorted array is:"<<endl;
    for(i=0;i<5;i++)
    {
        cout<<arr[i]<<endl;
    }

    return 0;
}