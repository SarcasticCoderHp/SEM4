#include<iostream>
#define MAX 10
using namespace std;

int queue[MAX],front,rear=-1;

void enque()
{
    int num;
    cout<<"Enter the data:";cin>>num;

    if(rear==MAX-1)
    {
       cout<<"Overflow";
    }
    else
    {
        if(front==-1 && rear==-1)
        {
            front=rear=0;
        }
        else
        {
            rear++;
            queue[rear]=num;
        }
    }
}

int deque()
{
    int val;

    if(front==-1 || front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        val=queue[front];
        front++;
    }
    return val;
}

int peek()
{
    return (queue[front]);
}

void display()
{
    if(front==-1 || front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        for(int i=front;i<=rear;i++)
        {
            cout<<queue[i]<<" ";
        }
        cout<<endl;
    }
}

void Evennodes()
{
    int evenCount=0;

    if(front==-1 || front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        for(int i=front;i<=rear;i++)
        {
            if(queue[i]%2==0)
            {
                cout<<queue[i]<<" ";
                evenCount++;
            }
            cout<<endl;
        }
    }

    cout<<"Even nodes are:"<<evenCount<<endl;
}

void Countnodes()
{
    int sum=0;
     if(front==-1 || front>rear)
    {
        cout<<"Underflow";
    }
    else
    {
        for(int i=front;i<=rear;i++)
        { 
           sum = sum+queue[i];
        }
         cout<<endl;
        }

    cout<<"Sum of nodes is:"<<sum<<endl;
}

int main()
{
    int val,option;

    do
    {
        cout<<"1.Enque"<<endl;
        cout<<"2.Deque"<<endl;
        cout<<"3.Peek"<<endl;
        cout<<"4.Display"<<endl;
        cout<<"5.Even"<<endl;
        cout<<"6.Sum nodes"<<endl;
        cout<<"7.Exit"<<endl;

        cout<<"Enter the option:";cin>>option;

        switch(option)
        {
            case 1:
            enque();
            cout<<endl;
            break;

            case 2:
            val=deque();
            cout<<"Deleted value is:"<<val<<endl;
            break;

            case 3:
            val=peek();
            cout<<"Value is:"<<val;
            cout<<endl;
            break;

            case 4:
            display();
            cout<<endl;
            break;

            case 5:
            Evennodes();
            cout<<endl;
            break;

            case 6:
            Countnodes();
            cout<<endl;
            break;

            case 7:
            return 0;
        }
    }while(option!=7);

    return 0;
}