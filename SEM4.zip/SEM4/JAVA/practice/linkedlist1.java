import java.util.LinkedList;
import java.io.*;

public class linkedlist1 {

    public static void main(String[] args) {
        
        LinkedList list1=new LinkedList();
       
        list1.add("FY");
        list1.add("SY");
        list1.add("TY");
        list1.add(10);
        list1.add(20);

        System.out.println("The list is:" +list1);

        list1.add(2,"Java");

        System.out.println("List is:"+list1);

        list1.addFirst("First");
        list1.addLast("Last");

        System.out.println("List is:"+list1);
    }
}
