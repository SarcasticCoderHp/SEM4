import java.io.*;
import java.util.Scanner;
import java.util.Vector;

public class vector3 {

    public static void main(String[] args) {

        Vector<String>vec=new Vector<String>();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 3 vector elements:");
        String name1=sc.next();
        String name2=sc.next();
        String name3=sc.next();

        vec.add(name1);
        vec.add(name2);
        vec.add(name3);
         
        System.out.println("Elements of vector:"+vec);
        System.out.println("Size of vector:" + vec.size());
        System.out.println("Capacity of vector:" + vec.capacity());

        System.out.println("Enter 3 more elements:");
        String name4=sc.next();
        String name5=sc.next();
        String name6=sc.next();

        vec.addElement(name4);
        vec.addElement(name5);
        vec.addElement(name6);

        System.out.println("Elements are:"+vec);
        System.out.println("Size of vector:"+vec.size());
        System.out.println("Capacity of vector:"+vec.capacity());

        if(vec.contains("Rat"))
        {
            System.out.println("Rat is present");
        }
        else
        {
            System.out.println("Rat not present");
        }

        System.out.println("First element of vector is:" + vec.firstElement());
        System.out.println("Last element of vector is:"+vec.lastElement());
    }
}
