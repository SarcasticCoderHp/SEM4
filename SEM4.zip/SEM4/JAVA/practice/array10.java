import java.util.Scanner;

class array10 {

    public int roll_no;
    public String name;
    Scanner sc = new Scanner(System.in);

    public void input()
    {
        System.out.print("Enter roll no:");
        roll_no=sc.nextInt();

        System.out.print("Enter the name:");
        name=sc.next();
    }

    public void display()
    {
        System.out.println("Name is:"+name);
        System.out.println("Roll no is:"+roll_no);
    }

    public static void main(String[] args)
    {
        array10 arr[] = new array10[2];

        for(int i=0;i<arr.length;i++)
        {
           // arr[i]=new array10();
            arr[i].input();
        }

        for(int i=0;i<arr.length;i++)
        {
            arr[i].display();
        }
    }
    
}
