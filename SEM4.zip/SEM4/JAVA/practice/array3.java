import java.util.Scanner;

public class array3{
        
        static void min(int arr[])
        {
            int min=arr[0];

            for(int i=0;i<arr.length;i++)
            {
                if(min>arr[i])
                {
                    min=arr[i];
                }
            }
            System.out.println("Minimum value is:" + min);
        }
   
    public static void main(String[] args)
    {
      int arr[] = new int[5];
      Scanner sc = new Scanner(System.in);

      System.out.println("Enter array elements:");
      for(int i=0;i<arr.length;i++)
      {
        arr[i]=sc.nextInt();
      }
       min(arr);
    }    
}
