import java.util.Scanner;

class problem13 {

    double Converter(double far)
    {
      double celcius = (far-32)/1.8;

        return celcius;

    }

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter value of farenheit:");
        int i = sc.nextInt();

        problem13 obj = new problem13();

        double result = obj.Converter(i);
         System.out.println("Celcius is:" + result);

    }
    
}
