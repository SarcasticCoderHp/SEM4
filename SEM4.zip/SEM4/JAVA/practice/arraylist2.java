import java.util.ArrayList;
import java.io.*;

public class arraylist2 {

    public static void main(String[] args) {
        
    ArrayList<String>cars = new ArrayList<String>();
    cars.add("Volvo");
    cars.add("Bmw");
    cars.add("Ford");

    for(String c:cars)
    {
        System.out.println(c);
    }

    ArrayList<Integer>list2 = new ArrayList<Integer>();
    list2.add(40);
    list2.add(20);
    list2.add(10);
    list2.add(50);

    Collections.sort(list2);

    for(Integer i:list2)
    {
    System.out.println(i);
    }
    }    
}
