import java.util.Scanner;

class problem12 {
    
       static void arith(int a,int b)
       {
          int sum =  a + b;
          int sub =  a - b;
          int mul =  a * b;
          int div =  a / b;
       
        System.out.println("Sum is:"+ sum);
         System.out.println("Sub is:"+ sub);
          System.out.println("Mul is:"+ mul);
           System.out.println("Sum is:"+ div);
       }

       public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter two numbers:");
        int x = sc.nextInt();
        int y = sc.nextInt();
         
        problem12 obj = new problem12();

        arith(x,y);

       }
}
