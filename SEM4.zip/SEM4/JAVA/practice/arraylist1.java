import java.util.ArrayList;

class program1
{
      public static void main(String[] args) {
        
        ArrayList<String>Bikes = new ArrayList<String>();

        Bikes.add("Ktm");
        Bikes.add("Hayabusa");
        Bikes.add("Ducati");
        Bikes.add("Royal Enfield");
        Bikes.add("Pagani");

        System.out.println("Bike at index 2 is:" + Bikes.get(3));

        if(Bike.contains("Ducati"))
        {
          System.out.println("Ducati is available");
        }
        else
        {
          System.out.println("Out of stock");
        }

        System.out.println("Bikes in sorted order:" + Bikes.sort());

        Bikes.clear();
      }
}