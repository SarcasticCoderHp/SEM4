import java.util.Scanner;

public class problem2 {

    public static void main(String[] args)
    {
           System.out.println("Taking user input!");

           Scanner sc = new Scanner(System.in);

           System.out.println("Enter value of num1");
           int num1 = sc.nextInt();

           System.out.println("Enter value of num2");
           int num2 = sc.nextInt();

           int sum = num1 + num2;

           System.out.println("The sum is");
           System.out.println(sum);

            }    
}
