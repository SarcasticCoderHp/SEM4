public class array9 {

    static void add(int...a)
    {
        int sum=0;
        for(int i=0;i<a.length;i++)
        {
            sum=sum+a[i];
        }
         System.out.println("The sum is:" + sum);
    }

    public static void main(String[] args) {
        
        add(1,2,3);
        add(20,30,40,50);
        add(11,22,33);
    }
    
}
