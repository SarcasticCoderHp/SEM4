import java.util.Scanner;

public class problem9 {

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string:");
        String name = sc.nextLine();

       /*int length = name.length();
        System.out.print("The length is:");
        System.out.println(length);*/


       /*String lcase = name.toLowerCase();
        System.out.print("The lowercase is:");
        System.out.println(lcase);*/


        /*String ucase = name.toUpperCase();
        System.out.print("The lowercase is:");
        System.out.println(ucase);*/


       // System.out.println(name.substring(4));
       //System.out.println(name.substring(1,3));


       //System.out.println(name.replace('e','a'));
       //System.out.println(name.replace("ell","all"));


       /*System.out.println(name.startsWith("He"));
       System.out.println(name.endsWith("ello"));*/
       

       //System.out.println(name.charAt(5));


       //System.out.println(name.indexOf("el"));
       //System.out.println(name.indexOf("  "));


       /*System.out.println(name.equals("Hello"));
       System.out.println(name.equalsIgnoreCase("HELLO"));*/
        

       //System.out.println(name.replace(" ","_"));
    }
    
}
