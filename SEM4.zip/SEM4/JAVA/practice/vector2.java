import java.io.*;
import java.util.Vector;

public class vector2 {
    public static void main(String[] args) {
        
        Vector<String>vec=new Vector<String>();

        vec.add("Tiger");
        vec.add("Lion");
        vec.add("Dog");
        vec.add("Elephant");

        System.out.println("Elements are:"+vec);
        System.out.println("Size of vector:"+vec.size());
        System.out.println("Capacity of vector:"+vec.capacity());

        vec.addElement("Rat");
        vec.addElement("Cat");
        vec.addElement("Deer");

        System.err.println("Elements are:"+vec);
        System.out.println("Size of vector:"+vec.size());
        System.out.println("Capacity of vector:"+vec.capacity());

        vec.add("lion");
        vec.add("dog");
        vec.add("elephant");

        System.out.println(vec);
        System.out.println("Size:"+vec.size());
        System.out.println("Capacity:"+vec.capacity());

        if(vec.contains("Tiger"))
        {
            System.out.println("Present");
        }
        else
        {
            System.out.println("Absent");
        }

        System.out.println("First element of vector:"+vec.firstElement());
        System.out.println("Last element of vector:"+vec.lastElement());
    }
}
