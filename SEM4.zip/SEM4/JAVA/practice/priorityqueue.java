import java.util.PriorityQueue;
import java.util.*;

public class priorityqueue {
    public static void main(String[] args) {
        
        PriorityQueue<Integer>pq=new PriorityQueue<Integer>();

        pq.add(10);
        pq.add(20);
        pq.add(30);

        System.out.println("Priority Queue is:" +pq);

        System.out.println("Top element of the queue:"+pq.peek());
        System.out.println("Top element print and remove:" + pq.poll());

      /*   Iterator itr=pq.iterator();
        while(itr.hasNext())
        {
            System.out.println(itr.next());
        }*/

        pq.add(40);
        pq.add(50);
        pq.add(60);

        System.out.println("Priority Queue is:" +pq);

        pq.remove(20);

        System.out.println("Priority Queue is:" +pq);

        System.out.println("Does queue contains 60:" + pq.contains(60));

    }
}
