public class array5 {

    public static void main(String[] args) {
        
        int arr[]={12,13,14,15,16};

        for(int i:arr)
        {
            System.out.println(i);
        }
    }
    
}
