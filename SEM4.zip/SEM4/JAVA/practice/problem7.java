import java.util.Scanner;

public class problem7 {
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter subject1 marks:");
        float subj1 = sc.nextFloat();

        System.out.println("Enter subject2 marks:");
        float subj2 = sc.nextFloat();

        System.out.println("Enter subject3 marks:");
        float subj3 = sc.nextFloat();

        System.out.println("Enter subject4 marks:");
        float subj4 = sc.nextFloat();

        System.out.println("Enter subject5 marks:");
        float subj5 = sc.nextFloat();

        float per = (subj1 + subj2 + subj3 + subj4 + subj5)*100/500;

        System.out.print("The percentage is: ");
        System.out.println(per);


    }
}
