import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Collection;
import java.io.*;

public class linkedlist2 {

    public static void main(String[] args) {
        
        LinkedList<String>list1=new LinkedList<String>();

        list1.add("FY");
        list1.add("SY");
        list1.add("TY");

        Collection<String>list2=new ArrayList<String>();
        list2.add("Hello");
        list2.add("Student");

        System.out.println("The linked list:"+list1);

       // list1.addAll(collect);
        list1.addAll(list2);
        
        System.out.println("New list is:" + list1);
    }
   
}
