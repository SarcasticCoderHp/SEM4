import java.util.Scanner;

public class problem8 {
    
    public static void main(String[] args)
    {
       /*float a = 7/4.0f * 9/2.0f;
       System.out.println(a);*/


       /*char grade = 'B';
       grade = (char)(grade - 8);
       System.out.prinltn(grade);*/
       

       /*Scanner sc = new Scanner(System.in);
       System.out.print("Enter a number:");
       int a = sc.nextInt();
       System.out.println(a>8);*/


      /*int v=5,u=10,a=5,s=5;
      int result = (v*v - u*u)/2*a*s;
      System.out.println(result);*/


      /*int x = 7;
      int a = (7*49/7) + (35/7);
      System.out.println(a);*/
       
    }
}
