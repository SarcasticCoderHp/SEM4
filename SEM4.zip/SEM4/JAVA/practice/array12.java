public class array12 {

    static void display(int...a)
    {
        int sum=0;
        System.out.print("The sum is:");
        for(int i:a)
        {
            sum=sum+i;
        }
        System.out.println(sum);
    }

    public static void main(String[] args) {
        display();
        display(1,2);
        display(5,10,20,25);
    }
    
}
