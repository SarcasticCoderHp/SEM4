//using applet

import java.awt.*; //paint
import java.applet.*; //init, start, stop and destroy

public class Applet1 extends Applet
	{  
		String msg="";

		public void init()
		{
			msg="Hello SYBCA";
		}
  
		public void start()
		{
			msg=msg+",Welcome to APPLET";
		}

		public void paint(Graphics g)
		{  
			g.drawString(msg,50,50);  
		}  
  
	}  
	
	/*<applet code="Applet1.class" width="500" height="500"></applet> */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	