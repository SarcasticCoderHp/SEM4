//using appletviewer


import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class Applet2 extends Applet
{  
  
	public void paint(Graphics g)
	{  
		g.setColor(Color.green);
		g.drawString("welcome to applet",150,150);  
	}  
  
}   


/*
<applet code="Applet2.class" width=400 height=400>
</applet>
*/