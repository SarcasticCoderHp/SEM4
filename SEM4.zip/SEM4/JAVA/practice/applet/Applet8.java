    /*
<applet code="Applet8" width=200 height=200>
</applet>
*/

import java.awt.*;
import java.applet.*;
public class Applet8  extends Applet
{
    public void paint(Graphics g)
    {
        g.setColor(Color.yellow);
        g.fillOval(40, 40, 120, 150); //face border

        g.setColor(Color.red);
        g.fillOval(57, 75, 30, 20); //eye
        g.fillOval(110, 75, 30, 20); //eye

        g.setColor(Color.white);
        g.fillOval(68, 81, 10, 10); //eye ball
        g.fillOval(121, 81, 10, 10); //eye ball

        g.setColor(Color.green);
        g.fillOval(85, 100, 30, 30); //nose

        g.setColor(Color.pink);
        g.fillArc(60, 125, 80, 40, 180, 180); //mouth
        
        g.setColor(Color.cyan);
        g.fillOval(25, 92, 15, 30); //ear
        g.fillOval(160, 92, 15, 30); //ear
    }

}
