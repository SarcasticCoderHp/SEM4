    import java.applet.Applet;
    import java.awt.Color;
    import java.awt.Graphics;
     
    public class Applet3_1 extends Applet {
     
     public void init() 
     {
      setBackground(Color.cyan);
      setForeground(Color.green);
     }
     
     public void paint(Graphics g)
     {
	     g.setColor(Color.red);
         g.drawString("Hello Java",150,150);
     }
    }
     
    /* 
    <applet code="Applet3_1" width=200 height=200>
    </applet>
    */