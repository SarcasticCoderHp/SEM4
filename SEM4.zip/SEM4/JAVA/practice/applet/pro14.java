import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class pro14 extends Applet {
    public void paint(Graphics g) {
        
        g.setColor(Color.YELLOW);
        g.fillOval(600, 400, 300, 300);

        g.setColor(Color.green);
        g.fillOval(690, 450, 20, 50);
        g.fillOval(795, 450, 20, 50);

        g.setColor(Color.black);
        g.fillOval(720, 550, 50, 50);

        g.setColor(Color.red);
        g.drawArc(690, 600, 130, 100, 0, 180);

    }
}
/* <applet code=pro14.class width=200 height=200></applet> */