import java.util.LinkedList;
import java.io.*;
import java.util.Scanner;

public class linkedlist3 {
    public static void main(String[] args) {
        
        LinkedList list = new LinkedList();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 5 elements:");
        String s1=sc.next();
        String s2=sc.next();
        String s3=sc.next();
        int s4=sc.nextInt();
        int s5=sc.nextInt();

        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(s4);
        list.add(s5);

        System.out.println("The list is:" + list);

        list.addFirst("First");
        list.addLast("Last");

        System.out.println("The list is:" + list);

        list.clear();
        System.out.println("List clear");

        System.out.println("Enter 2 new elements:");
        String s6=sc.next();
        String s7=sc.next();

        list.add(s6);
        list.add(s7);

        System.out.println("The list is:" + list);
        
        System.out.println("=====================================");

        LinkedList list2=new LinkedList();
        
        list2=list.clone();
        System.out.println("The list is:" + list);
        System.out.println("Second list is:" + list2);

        System.out.println("Does it conatins SY:" + list.contains("SY"));

        list.add(1);
        list.add(2);

        System.out.println("Getting second index value:" + list.get(1));
        System.out.println("Getting first element:" + list.getFirst());
        System.out.println("Getting last element:" + list.getLast());

        list.add("SY");

        System.out.println("First occurrence of SY:"+list.indexOf("SY"));
        System.out.println("Last occurrence of SY:"+list.lastIndexOf("SY"));

        System.out.println("Remove head element:"+list.remove());
        System.out.println("Remove 4th element:"+list.remove(2));
        System.out.println("Remove last element:"+list.removeLast());

        System.out.println("Replaced object is:"+list.set(1,50));
        System.out.println(list);

        System.out.println("Size of list:"+list.size());

    }
}
