import java.util.*;
import java.util.Stack;

public class stack {
    public static void main(String[] args) {
        
        Stack stack1=new Stack();
        stack1.push(4);
        stack1.push("SY");
        stack1.push("IMSCIT");

        Stack stack2=new Stack();
        stack2.push("SY");
        stack2.push("IMSCIT");
        stack2.push("STUDENT");

        System.out.println("Stack 1 is:"+stack1);
        System.out.println("Stack 2 is:"+stack2);

        System.out.println("Top element os stack 1:"+stack1.peek());
        System.out.println("Top element of stack 2:"+stack2.peek());

        System.out.println("Popped element stack 1:"+stack1.pop());
        System.out.println("Popped element stack 2:"+stack2.pop());

        System.out.println("Stack 1 is:"+stack1);
        System.out.println("Stack 2 is:"+stack2);
        
        int position1=stack1.search("SY");
        System.out.println("Position of element:"+position1);

        int position2=stack2.search("SY");
        System.out.println("Position of element:"+position2);


        stack1.clear();
        stack2.clear();

        System.out.println("Size stack1:"+stack1.size());
        System.out.println("Size stack2:"+stack2.size());
    }
}
