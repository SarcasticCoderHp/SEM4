import javax.swing.JOptionPane;

class problem11
{
    public static void main(String[] args)
    {
        String n1=JOptionPane.showInputDialog("Enter first number:");
        String n2=JOptionPane.showInputDialog("Enter second number:");

        int ans=Integer.parseInt(n1) + Integer.parseInt(n2);

        JOptionPane.showMessageDialog(null, "Answer is:"+ans,"Answer",JOptionPane.INFORMATION_MESSAGE);
    }
}