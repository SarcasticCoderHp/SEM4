public class array6 {

    public static void main(String[] args) {
        
        double arr[]={1.5,6.4,3.9,4.4,9.1};

        for(double d:arr)
        {
            System.out.println(d);
        }
    }
    
}
