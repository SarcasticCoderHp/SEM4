import java.util.Scanner;

public class problem4 {
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter subject 1:");
        int subj1=sc.nextInt();

        System.out.println("Enter subject 2:");
        int subj2=sc.nextInt();

        System.out.println("Enter subject 3:");
        int subj3=sc.nextInt();

        float cgpa = (subj1 + subj2 + subj3)/30;

        System.out.print("Your cgpa is: ");
        System.out.println(cgpa);
    }
}
