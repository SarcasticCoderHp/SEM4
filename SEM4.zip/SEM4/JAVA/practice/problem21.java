public class problem21
{
         public static void main(String[] args)
         {   
     
         int mylist[] = {1,2,3,4,5};

         for(int d:mylist)
         {
            System.out.println(d);
         }
        }
}

