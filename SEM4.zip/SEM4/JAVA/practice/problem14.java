import java.util.Scanner;

class problem14 {

    problem14(double b,double h)
    {
        double area =  0.5 * b * h;
        System.out.println("Area of triangle:" + area);
    }

    problem14(int l,int w)
    {
        int area =  l * w;
        System.out.println("Area of rectangle:" + area);
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the width and height of triangle:");
        double b = sc.nextDouble();
        double h = sc.nextDouble();

        System.out.print("Enter the length and width of rectangle:");
        int l = sc.nextInt();
        int w = sc.nextInt();

        problem14 obj1 = new problem14(b,h);
        problem14 obj2 = new problem14(l,w);
   
    }
    
}
