public class problem1 {
    
    public static void main(String[] args)
    {
        int a=20,b=10;
        int sum,sub,mul,div;

        sum=a+b;
        sub=a-b;
        mul=a*b;
        div=a/b;

        System.out.println(sum);
        System.out.println(sub);
        System.out.println(mul);
        System.out.println(div);
    }
}
