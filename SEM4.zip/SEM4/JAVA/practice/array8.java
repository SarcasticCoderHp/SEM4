public class array8 {

    static int[] printArray(int[] arr)
    {
       return arr;
    }

    public static void main(String[] args) {
        
        int arr[]={1,2,3,4,5};
        int temp[]=printArray(arr);

        for(int i=0;i<temp.length;i++)
        {
            System.out.println(temp[i]);
        }
    }
    
}
