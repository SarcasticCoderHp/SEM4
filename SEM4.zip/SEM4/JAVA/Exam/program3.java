class Book
{
    String title;
    int totalpages;

    Book(String title,int totalpages)
    {
        this.title=title;
        this.totalpages=totalpages;
    }

    public String getTitle()
    {
        return title;
    }

    public int getPages()
    {
        return totalpages;
    }

    public void setTitle(String title)
    {
        this.title=title;
    }

    public void setPages(int totalpages)
    {
        this.totalpages=totalpages;
    }
}

class Textbook extends Book
{
    char gradelevel;

    Textbook(String title,int totalpages,char gradelevel)
    {
        super(title,totalpages);
        this.gradelevel=gradelevel;
    }

    public char getGrade()
    {
        return gradelevel;
    }

    public void setGrade(char gradelevel)
    {
        this.gradelevel=gradelevel;
    }
}

class program3
{
    public static void main(String[] args) {
        
        Book b1 = new Book("Java Special",500);
        System.out.println("Book title:" + b1.getTitle());
        System.out.println("Book pages:" + b1.getPages());

        Textbook t1 = new Textbook("Java Journey", 350, 'A');
        System.out.println("Book title:" + t1.getTitle());
        System.out.println("Book pages:" + t1.getPages());
        System.out.println("Grade level:" + t1.getGrade());
    }
}