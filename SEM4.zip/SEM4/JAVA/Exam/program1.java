import java.util.Scanner;

interface Area
{
   double Calculatearea();
}

class circle implements Area
{
   double radius;

   circle(double radius)
   {
    this.radius=radius;
   }

   public double Calculatearea()
   {
    return 3.14*radius*radius;
   }
}

class rectangle implements Area
{
    double length,width;

    rectangle(double length,double width)
    {
        this.length=length;
        this.width=width;
    }

    public double Calculatearea()
    {
        return length*width;
    }
}

class square implements Area
{
    double side;

    square(double side)
    {
        this.side=side;
    }

    public double Calculatearea()
    {
        return side*side;
    }
}

class program1
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter radius of circle:");
        double radius=sc.nextDouble();
        circle c1 = new circle(radius);
        System.out.println("Area of circle:" + c1.Calculatearea());

        System.out.println("Enter length and width of rectangle:");
        double length=sc.nextDouble();
        double width=sc.nextDouble();
        rectangle r1 = new rectangle(length,width);
        System.out.println("Area of rectangle:" + r1.Calculatearea());

        System.out.println("Enter the side of square:");
        double side=sc.nextDouble();
        square s1 = new square(side);
        System.out.println("Area of square:" + s1.Calculatearea());
    }
}