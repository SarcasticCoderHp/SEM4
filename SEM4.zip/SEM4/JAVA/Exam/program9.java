import java.util.Scanner;

class myexception extends Exception
{
    myexception(String message)
    {
        super(message);
    }
}

class account
{
    int balance;

    public void deposit(int amount)
    {
        balance+=amount;
        System.out.println("Deposited amount is:" + amount);
    }

    public void withdraw(int amount) throws myexception
    {
      if(balance>=amount)
      {
        balance-=amount;
        System.out.println("Withdrawn amount is:" + amount);
      }
      else
      {
        throw new myexception("Not enough funds");
      }
    }

    public int getBalance()
    {
        return balance;
    }
}

class program9
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        account a1 = new account();

        System.out.println("Enter the amount to deposit:");
        int damount=sc.nextInt();
        a1.deposit(damount);

        int wamount=0;

        try
        {
        do
        {
            System.out.println("Enter the amount to withdraw:");
            wamount=sc.nextInt();
            a1.withdraw(wamount);
            System.out.println("Current balance is:" + a1.getBalance());

        }while(damount>=wamount);
    }
    catch(myexception e)
    {
        System.out.println(e.getMessage());
    }
    }
}