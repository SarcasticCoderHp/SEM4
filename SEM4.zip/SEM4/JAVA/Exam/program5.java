import java.util.Scanner;

interface area_perimeter
{
	void area();
	void perimeter();
}

class Rectangle implements area_perimeter
{
    int length;
	int width;

	public void area()
	{
		int area=this.length*this.width;
		System.out.println("Area of rectangle:" + area);
	}

	public void perimeter()
	{
		int perimeter=2*(this.length+this.width);
		System.out.println("Perimeter of rectangle:" + perimeter);
	}
}

class box implements area_perimeter
{
	int side;

	public void area()
	{
		int area=this.side*this.side;
		System.out.println("Area of box:" + area);
	}

	public void perimeter()
	{
		int perimeter=this.side*this.side*this.side*this.side;
		System.out.println("Perimeter of box:" + perimeter);
	}
}

class program5
{
    public static void main(String[] args) {
     
        Scanner sc = new Scanner(System.in);

        Rectangle r1 = new Rectangle();
        System.out.println("Enter width and height of rectangle:");
        int length=sc.nextInt();
        int width=sc.nextInt();

        r1.length=length;
        r1.width=width;

        r1.area();
        r1.perimeter();

        System.out.println();

        box b1 = new box();
        System.out.println("Enter side of box:");
        int side=sc.nextInt();
        b1.side=side;

        b1.area();
        b1.perimeter();

    }
}