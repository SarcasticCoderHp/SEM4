import java.util.Scanner;

interface sports
{
    int total(int m1,int m2,int m3);
    double percentage(int total,int sportMarks);
}

class Result implements sports
{
    public int total(int m1,int m2,int m3)
    {
        return m1+m2+m3;
    }

    public double percentage(int total,int sportMarks)
    {
        return (total+sportMarks)/4;
    }

    public char Grade(double percentage)
    {
        char grade;

        if(percentage>80)
        {
           grade='A';
        }

        else if(percentage<80 && percentage>60)
        {
            grade='B';
        }
        else if(percentage<60 && percentage<40)
        {
            grade='C';
        }
        else 
        {
            grade='D';
        }

        return grade;
    }
}

class program6
{
    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);

        Result r1 = new Result();

        System.out.println("Enter 3 subject marks:");
        int m1=sc.nextInt();
        int m2=sc.nextInt();
        int m3=sc.nextInt();

        int total=r1.total(m1,m2,m3);

        System.out.println("Enter sports marks:");
        int sm = sc.nextInt();

        double percentage=r1.percentage(total, sm);

        char grade=r1.Grade(percentage);

        System.out.println("Total is:" + total);
        System.out.println("Sports marks:" + sm);
        System.out.println("Percentage is:" + percentage);
        System.out.println("Grade is:" + grade);
    }
}

