class superclass
{
    int num1;

    superclass(int num1)
    {
        this.num1=num1;
    }

    public int getNum1()
    {
        return num1;
    }
}

class subclass extends superclass
{
    int num2;

    subclass(int num1,int num2)
    {
        super(num1);
        this.num2=num2;
    }

    public int getNum2()
    {
        return num2;
    }
}

class program4
{
    public static void main(String[] args) {
        
     subclass s1 = new subclass(10,20);
     System.out.println(s1.getNum1());
     System.out.println(s1.getNum2());

    }
}