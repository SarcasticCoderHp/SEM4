import java.util.Scanner;

interface Numbers
{
    int process(int x,int y);
}

class sum implements Numbers
{
    public int process(int x,int y)
    {
        return x+y;
    }
}

class average implements Numbers
{
    public int process(int x,int y)
    {
        return (x+y)/2;
    }
}

class program2
{
    public static void main(String[] args) {
        
      Scanner sc = new Scanner(System.in);

      System.out.println("Enter two numbers:");
      int a=sc.nextInt();
      int b=sc.nextInt();

      sum s1 = new sum();
      int Sum = s1.process(a,b);
      System.out.println(Sum);

      average avg = new average();
      int Avg = avg.process(a,b);
      System.out.println(Avg);
    }
}