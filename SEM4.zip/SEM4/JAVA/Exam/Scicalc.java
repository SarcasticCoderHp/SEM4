package Scicalculator;
import Calc.Calculator;

public class Scicalc
{
    public double squareroot(double a)
    {
       return Math.sqrt(a);
    }

    public static void main(String[] args) {
        
        Calculator c1 = new Calculator();
        int sum=c1.sum(10,20);
        int sub=c1.sub(20,10);

        Scicalc s1 = new Scicalc();
        double sqrt = s1.squareroot(64);

        System.out.println(sum);
        System.out.println(sub);
        System.out.println(sqrt);
    }
    
}