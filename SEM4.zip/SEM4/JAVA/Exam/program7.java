import java.util.Scanner;

class Rectangle
{
    int length;
    int width;

    Rectangle(int length,int width)
    {
        this.length=length;
        this.width=width;
    }

    public void rarea(int length,int width)
    {
        int rarea=length*width;
        System.out.println("Area of rectangle:" + rarea);
    }

    public void rperimeter(int length,int width)
    {
        int rperi=2*(length+width);
        System.out.println("Perimter of rectangle:" + rperi);
    }
}

class Square extends Rectangle
{
    int side;

    Square(int side)
    {
        super(side,side);
    }

    void sarea(int side)
    {
        int sarea=side*side;
        System.out.println("Area of square:" + sarea);
    }

    void sperimeter(int side)
    {
        int speri=side*side*side*side;
        System.out.println("Perimeter of square:" + speri);
    }
}

class program7
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
 
        System.out.println("Enter length and width of rectangle:");
        int length=sc.nextInt();
        int width=sc.nextInt();
        Rectangle r1 = new Rectangle(length, width);
        r1.rarea(length, width);
        r1.rperimeter(length,width);

        System.out.println();

        System.out.println("Enter side of square");
        int side=sc.nextInt();
        Square s1 = new Square(side);
        s1.sarea(side);
        s1.sperimeter(side);
        
    }
}