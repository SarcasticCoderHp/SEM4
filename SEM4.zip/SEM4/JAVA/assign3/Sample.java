package mypack1;
import MyPackage.Student;

public class Sample
{
  public static void main(String[] args) {
    
    Student obj = new Student(101,"Shubham","Tejas","Shah","Ahmedabad",19);

    System.out.println("Roll no:" + obj.getRollno());
    System.out.println("First name:" + obj.getFname());
    System.out.println("Middle name:" + obj.getMname());
    System.out.println("Last name:" + obj.getLname());
    System.out.println("Address:" + obj.getAddress());
    System.out.println("Age:" + obj.getAge());
  }  
}