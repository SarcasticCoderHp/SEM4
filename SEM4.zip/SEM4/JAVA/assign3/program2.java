import java.util.Scanner;

class employee
{
    Scanner sc = new Scanner(System.in);

    String name;
    String designation;
    

void display1()
{
    System.out.println("Name is:" + name);
    System.out.println("Designation is:" + designation);
}
}

class emp extends employee
{
    int salary;

    void get()
    {
    System.out.print("Enter emp name:");
    name=sc.next();

    System.out.print("Enter emp designation:");
    designation=sc.next();

    System.out.print("Enter the salary:");
    salary=sc.nextInt();
    }

    void display2()
    {
        System.out.println("Salary is:" + salary);
    }
}
  

class program2
{
    public static void main(String[] args)
    {
        emp obj = new emp();
        obj.get();
        obj.display1();
        obj.display2();
    }
}