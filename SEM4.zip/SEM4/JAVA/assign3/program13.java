import java.util.Scanner;

class Rectangle
{
    int length,width;

    Rectangle(int length,int width)
    {
        this.length=length;
        this.width=width;
    }

    int area()
    {
        return length*width;
    }

    int perimeter()
    {
        return 2*(length+width);
    }
}

class Square extends Rectangle
{
    int side;

    Square(int side)
    {
        super(side,side);
    }

    public int Perimeter(int side)
    {
        return side*side*side*side;
    }
}


class program13
{
  public static void main(String args[])
  {
    Scanner sc = new Scanner(System.in);

     System.out.print("Enter length and width of rectangle:");
     int length = sc.nextInt();
     int width = sc.nextInt();

     Rectangle r1 = new Rectangle(length,width);
     System.out.println("Area of rectangle:" + r1.area());
     System.out.println("Perimeter of rectangle:" + r1.perimeter());


     System.out.println("Enter the side of square:");
     int side=sc.nextInt();

     Square s = new Square(side);
     System.out.println("Area of square:" + s.area());
     System.out.println("Perimeter of square:" + s.Perimeter(side));
     
  }
}