interface Dog
{
    void bark();
}

interface Tiger
{
    void roar();
}

class Animal implements Dog,Tiger
{
   public void bark()
   {
          System.out.println("Dog is barking");
   }

    public void roar()
    {
        System.out.println("Tiger is roraring");
    }
}

class program8
{
    public static void main(String[] args) {
        
        Animal obj = new Animal();
        obj.bark();
        obj.roar();
    }
}