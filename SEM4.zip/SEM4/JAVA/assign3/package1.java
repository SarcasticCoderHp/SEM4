package mypack;
import pack.*;

public class package1
{
    public static void main(String[] args)
    {
        program15 obj = new program15();
        obj.area();
    }
}