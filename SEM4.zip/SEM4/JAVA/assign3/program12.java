import java.util.Scanner;

interface sports
{
    int total(int m1,int m2,int m3);
    float percent(int total,int Sportmarks);
}

class result implements sports
{

    public int total(int m1,int m2,int m3)
    {
        return m1+m2+m3;
    }

    public float percent(int total,int Sportmarks)
    {
        return (total+Sportmarks)/4;
    }

    public char Grade(float percentage)
    {
        if(percentage>80)
        {
            return 'A';
        }
        else if(percentage>60 && percentage<80)
        {
            return 'B';
        }
        else if(percentage>40 && percentage<60)
        {
            return 'C';
        }
        else
        {
            return 'D';
        }
    }
}

class program12
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 3 marks:");
        int m1=sc.nextInt();
        int m2=sc.nextInt();
        int m3=sc.nextInt();

        System.out.println("Enter sports marks:");
        int sm = sc.nextInt();

        result rs = new result();
        int total=rs.total(m1,m2,m3);
        float per=rs.percent(total,sm);
        char grade=rs.Grade(per);

        System.out.println("Total marks:" + total);
        System.out.println("Sports marks:" + sm);
        System.out.println("Percentage:" + per);
        System.out.println("Grade:" + grade);
        
    }
}