package pack;
import java.util.Scanner;

public class program15
{
    public void area()
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter width and height of rectangle:");
        double width=sc.nextDouble();
        double height=sc.nextDouble();

        double area=width*height;

        System.out.println("Area of rectangle:" + area);
    }
}