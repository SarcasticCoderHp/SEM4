import java.util.Scanner;

interface Numbers
{
    int process(int x,int y);
}

class sum implements Numbers
{
    public int process(int x,int y)
    {
        return x+y;
    }
}

class average implements Numbers
{
   public int process(int x,int y)
    {
        return (x+y)/2;
    }
}

class program5
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter two numbers:");
        int a = sc.nextInt();
        int b = sc.nextInt();

       sum s = new sum();
       System.out.println("Sum is:" + s.process(a,b)); 

       average av = new average();
       System.out.println("Average is:" + av.process(a,b));
    }
}
