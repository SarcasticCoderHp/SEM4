package Package1;

public class ImportExample
{
    public void Display()
    {
        System.out.print("This is example of importing package from other classes");
    }
}