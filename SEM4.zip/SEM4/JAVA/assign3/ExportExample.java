package Package2;
import Package1.ImportExample;

public class ExportExample
{
    public static void main(String[] args) {
        
    ImportExample obj = new ImportExample();
    obj.Display();
}
}