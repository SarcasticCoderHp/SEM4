package newPack1;
import newPack.hello.program17;

public class Newpack1 extends program17 {

    public void display2()
    {
        System.out.println("Object of Newpack1 class");
    }
    public static void main(String[] args) {
        
       Newpack1 s1 = new Newpack1();

        s1.display1();
        s1.display2();
    }
    
}
