import java.util.Scanner;

class Book
{
    String title;
    int total_pages;

    Book(String title,int total_pages)
    {
        this.title=title;
        this.total_pages=total_pages;
    }

    
    //getter
    public String getTitle()
    {
        return title;
    }

    public int getPages()
    {
        return total_pages;
    }

    //setter
    public void setTitle(String title)
    {
        this.title=title;
    }

    public void setPages(int total_pages)
    {
        this.total_pages=total_pages;
    }
}

class Textbook extends Book
{
    char grade;

    Textbook(String title,int total_pages,char grade)
    {
        super(title,total_pages);
        this.grade=grade;
    }

    //getter
    public char getGrade()
    {
        return grade;
    }

    public void setGrade(char grade)
    {
        this.grade=grade;
    }

}

class program6
{
    public static void main(String[] args) {
        
        Book b1 = new Book("Java program",500);
        System.out.println("Book title for b1:" + b1.getTitle());
        System.out.println("Book pages for b1:" + b1.getPages());

        Textbook t1 = new Textbook("Java oop",200,'A');
        System.out.println("Book title for t1:" + t1.getTitle());
        System.out.println("Book pages for t1:" + t1.getPages());
        System.out.println("Book grade for t1:" + t1.getGrade());

    }
    
}