package Example2;
import Example1.Display1;

public class Display2 extends Display1
{
    public void display2()
    {
        System.out.println("Hello world from Example2");
    }
    
    public static void main(String[] args)
    {
        Display2 obj1 = new Display2();
        obj1.display1();
        obj1.display2();
    }
}