import java.util.Scanner;

class arithmean
{
      Scanner sc = new Scanner(System.in);
 
      void armean()
      {
      int i, sum=0;
      float arithmean;
      
      int[] arr = new int[5];
      
      System.out.print("Enter Numbers: ");
      for(i=0; i<5; i++)
      {
         arr[i] = sc.nextInt();
         sum = sum + arr[i];
      }
      
      arithmean = sum/5;
      System.out.println("Arithmetic Mean:" +arithmean);
}
}

class Stddeviation extends arithmean
{
    int stddeviation;
 
   void stddev()
   {
   System.out.println("Standard deviation is:" + stddeviation);
   }
}

class program3
{
    public static void main(String[] args)
    {
        Stddeviation obj = new Stddeviation();
        obj.armean();
        obj.stddev();
    }
}