package MyPackage;

public class Student
{
   public int rollno;
   public String fname;
   public String mname;
   public String lname;
   public String address;
   public int age;

   public Student(int rollno,String fname,String mname,String lname,String address,int age)
   {
    this.rollno=rollno;
    this.fname=fname;
    this.mname=mname;
    this.lname=lname;
    this.address=address;
    this.age=age;
   }

//Getters

   public int getRollno()
   {
    return rollno;
   }

   public String getFname()
   {
    return fname;
   }

   public String getMname()
   {
    return mname;
   }

   public String getLname()
   {
    return lname;
   }

   public String getAddress()
   {
    return address;
   }

   public int getAge()
   {
    return age;
   }

   //Setters
 
   public void setRollno(int rollno)
   {
    this.rollno=rollno;
   }

   public void setFname(String fname)
   {
    this.fname=fname;
   }

   public void setMname(String mname)
   {
    this.mname=mname;
   }

   public void setLname(String lname)
   {
    this.lname=lname;
   }

   public void setAddress(String address)
   {
    this.address=address;
   }

   public void setAge(int age)
   {
    this.age=age;
   }
}