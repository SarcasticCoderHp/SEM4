package Example1;

public class Display1
{
    public void display1()
    {
        System.out.print("Hello World from Example1");
    }
}