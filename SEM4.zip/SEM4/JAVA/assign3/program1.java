import java.util.Scanner;

class MotorVehicle
{
    String modelname;
    int modelno;
    int modelprice;

  MotorVehicle(String a,int b,int c)
  {
    modelname=a;
    modelno=b;
    modelprice=c;
  }

void display1()
    {
        System.out.println("Car name is:" + modelname);
        System.out.println("Model no is:" + modelno);
        System.out.println("Car price is:" + modelprice);
    }
}

class Car extends MotorVehicle
{
    int discountrate;

    Car(String a,int b,int c,int d)
    {
      super(a,b,c);
      discountrate=d;  
    }

    void display2()
    {
        System.out.println("Discount rate is:" + discountrate);
    }
}

class program1
{
public static void main(String[] args)
{
       Scanner sc = new Scanner(System.in);

       String modelname;
       int modelno,modelprice,discountrate;

       System.out.print("Enter model name:");
       modelname=sc.next();

       System.out.print("Enter model no:");
       modelno=sc.nextInt();

       System.out.print("Enter model price:");
       modelprice=sc.nextInt();

       System.out.print("Enter discount rate:");
       discountrate=sc.nextInt();

       Car c1 = new Car(modelname,modelno,modelprice,discountrate);
       c1.display1();
       c1.display2();
}
}

