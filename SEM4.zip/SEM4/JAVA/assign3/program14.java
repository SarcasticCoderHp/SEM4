class Shape
{
    void display1()
    {
        System.out.println("This is shape");
    }
}

class Rectangle extends Shape
{
    void display2()
    {
        System.out.println("This is rectangle");
    }
}

class Circle extends Shape
{
    void display3()
    {
        System.out.println("This is circle");
    }
}

class Square extends Rectangle
{
    void display4()
    {
        System.out.println("Square is rectangle");
    }
}

class program14
{
    public static void main(String[] args)
    {
        Square s1 = new Square();
        s1.display2();
        s1.display1();
    }
}