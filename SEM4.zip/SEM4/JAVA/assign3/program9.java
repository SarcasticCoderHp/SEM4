class parentclass
{
	static void print()
	{
		System.out.print("This is parent class");
	}
}

class childclass extends parentclass
{
	static void Print()
	{
		System.out.println("This is child class");
	}
}

class program9
{
	public static void main(String[] args) {
		
        parentclass p1 = new parentclass();
        p1.print();

        System.out.println();

		childclass c1 = new childclass();
		c1.Print();

		System.out.println();
		c1.print();
	}
}