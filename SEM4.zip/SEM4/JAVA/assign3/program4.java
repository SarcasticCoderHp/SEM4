import java.util.Scanner;

interface CalculateArea
{
    double calculate();
}

class circle implements CalculateArea
{
    double radius;

    circle(double radius)
    {
        this.radius=radius;
    }

    public double calculate()
    {
        return 3.14*radius*radius;
    }
}

class rectangle implements CalculateArea
{
    double length,width;

    rectangle(double length,double width)
    {
        this.length=length;
        this.width=width;
    }

    public double calculate()
    {
        return length*width;
    }
}

class square implements CalculateArea
{
    double side;

    square(double side)
    {
        this.side=side;
    }

    public double calculate()
    {
        return side*side;
    }
}

class program4
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter radius of circle");
        double radius = sc.nextDouble();
        circle c = new circle(radius);
        System.out.println("Area of circle:" + c.calculate());

        System.out.println("Enter length and width of rectangle");
        double length = sc.nextDouble();
        double width = sc.nextDouble();
        rectangle r = new rectangle(length,width);
        System.out.println("Area of rectangle:" + r.calculate());

        System.out.println("Enter side of square");
        double side = sc.nextDouble();
        square s = new square(side);
        System.out.println("Area of square:" + s.calculate());
        
    }
}