import java.util.Scanner;

interface Area
{
    float PI = 3.14f;
    float compute(float radius,float height);
}

class Cylinder implements Area
{
    public float compute(float radius,float height)
    {
        return PI*radius*radius*height;
    }
}

class program11
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter radius and height:");
        float radius = sc.nextFloat();
        float height = sc.nextFloat();

        Cylinder c1 = new Cylinder();

        System.out.println("Area of cylinder:" + c1.compute(radius, height));
    }
}