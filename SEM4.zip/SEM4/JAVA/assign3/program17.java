package newPack.hello;

public class program17 {
    
    public void display1()
    {
        System.out.println("Object of program17 class");
    }
}
