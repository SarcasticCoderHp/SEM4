package Scicalc;
import  Calc.Calculator;

public class Scicalculator
{
   public double squareroot(double a)
   {
      return Math.sqrt(a);
   }
   public static void main(String[] args) 
   {
      Calculator c1 = new Calculator();
      int Sum = c1.sum(10,20);
      int Sub = c1.sub(20,10);

      Scicalculator s1 = new Scicalculator();
      double Sqroot = s1.squareroot(64);

      System.out.println("Addition is:" + Sum);
      System.out.println("Subtraction is:" + Sub);
      System.out.println("Square root is:" + Sqroot);

}
}