class Superclass
{
    int num1;

    Superclass(int num1)
    {
        this.num1=num1;
        System.out.println("This is superclass");
    }

    public int getNum1()
    {
        return num1;
    }
}

class Subclass extends Superclass
{
   int num2;

   Subclass(int num1,int num2)
   {
    super(num1);
    this.num2=num2;
   }

   public int getNum2()
   {
     return num2; 
   }
}

class program7
{
    public static void main(String[] args) {
        
        Subclass s1 = new Subclass(10,50);
        System.out.println("Superclass num:" + s1.getNum1());
        System.out.println("Subclass num:" + s1.getNum2());
    }
}