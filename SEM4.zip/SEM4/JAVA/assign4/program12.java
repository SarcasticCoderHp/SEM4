import java.util.Scanner;

public class program12 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter total integers");
        int n = sc.nextInt();

        int array[] = new int[n];

        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++)
        {
            array[i] = sc.nextInt();
        }

        for(int i=0;i<n-1;i++)
        {
            for(int j=0;j<n-i-1;j++)
            {
                if(array[j] < array[j+1])
                {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                }
            }
        }

        System.out.println("Array in descending order is:");
        for(int i=0;i<n;i++)
        {
            System.out.println(array[i]);
        }

        System.out.println("Enter an index to search:");
        int index = sc.nextInt();

        try{
                if(index<0 || index>n)
                {
                    throw new ArrayIndexOutOfBoundsException();
                   
                }
                else
                {
                    System.out.println("Element at index is:" + array[index]);
                }
                
            }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
    }
    
}
