import java.util.Scanner;

public class program16 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        int array[] = new int[5];

        System.out.println("Enter 5 array elements");
        for(int i=0;i<5;i++)
        {
            array[i] = sc.nextInt();
        }

        System.out.println("Array elements are:");
        for(int i=0;i<5;i++)
        {
            System.out.println(array[i]);
        }

        System.out.println("Enter an array index to get element:");
        int index = sc.nextInt();

        try
        {
            if(index<0 || index>5)
            {
                throw new ArrayIndexOutOfBoundsException();
            }
            else
            {
                System.out.println("Element at index is:" + array[index]);
            }
        }

        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
    }
    
}
