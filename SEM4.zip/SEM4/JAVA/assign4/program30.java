public class program30 {

    public static void main(String[] args) {

        Byte B = new Byte((byte) 10);  
        byte b = B;                    

        Short S = new Short((short) 20);   
        short s = S;                      

        Integer I = new Integer(15);   
        int i = I;                     

        Long L = new Long(50);     
        long l = L;               

        Float F = new Float(20);     
        float f = F;                 

        Double D = new Double(20.5);   
        double d = D;     
        System.out.println(d);           

        Boolean BLN = new Boolean(true);      
        boolean bln = BLN;                   

        Character C = new Character('C');   
        char c = C;        
        System.out.println(c);               
    }
}
