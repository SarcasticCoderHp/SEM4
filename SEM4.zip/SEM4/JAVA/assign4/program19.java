import java.util.Scanner;

class myexception extends Exception
{
   public myexception(String message)
   {
      super(message);
   }
}

class account
{
    int balance;

    public void Deposit(int amount)
    {
        balance+=amount;
        System.out.println("Deposited amount is:" + amount);
    }

    public void withdraw(int amount) throws myexception
    {
        if(balance>=amount)
        {
            balance-=amount;
            System.out.println("Withdrawn amount is:" + amount);
        }
        else
        {
            throw new myexception("Not Sufficient Fund");
        }
    }

    public int getBalance()
    {
        return balance;
    }
}

public class program19
{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        account a1 = new account();

    try
    {
        System.out.println("Enter amount to be deposited:");
        int damount = sc.nextInt();
        a1.Deposit(damount);

        int wamount=0;

       do{

        System.out.println("Enter amount to be withdrawn:");
        wamount = sc.nextInt();
        a1.withdraw(wamount);

        System.out.println("Current balance is:" + a1.getBalance());
        
       } while(damount>=wamount);
    }
    catch(myexception e)
    {
        System.out.println(e.getMessage());
    }
}
}