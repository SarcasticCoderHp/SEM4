public class program26 {

    public static void main(String[] args) {
        
        String s = "FCAIT Gls University";

        System.out.println("Upprcase is:" + s.toUpperCase());
        System.out.println("Lowercase is:" + s.toLowerCase());
        System.out.println("Char at index 5 is:" + s.charAt(4));
        System.out.println("Substring is:" + s.substring(7, 20));
    }
}
