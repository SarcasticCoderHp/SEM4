import java.util.Scanner;

class program11
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a numerator:");
		int num = sc.nextInt();

		System.out.println("Enter a denominator:");
		int den = sc.nextInt();

		try
		{
			if(den==0)
			{
				throw new ArithmeticException();
			}
			else
			{
				System.out.println(num/den);
			}
		}
		catch(ArithmeticException e)
		{
			System.out.println("denominator cant be zero");
		}
	

	finally
	{
		System.out.print("This is finally block");
	}
}
}
	
