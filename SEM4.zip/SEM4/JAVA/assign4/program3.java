import java.util.Scanner;

public class program3 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        try
        {
            System.out.println("Enter n numbers:");
            int n = sc.nextInt();

            int numbers[] = new int[n];

            if(n<=2)
            {
                throw new IllegalArgumentException("Enter atleast 3 numbers");
            }
            else
            {
                System.out.println("Enter integers:");
                for(int i=0;i<n;i++)
                {
                    numbers[i] = sc.nextInt();
                }
            }

            int lowest=numbers[0];
            int slowest=numbers[1];

            for(int i=2;i<n;i++)
            {
                if(numbers[i]<lowest)
                {
                    slowest=lowest;
                    lowest=numbers[i];
                }
                else if(numbers[i] < slowest && numbers[i]!=lowest)
                {
                    slowest=numbers[i];
                }
            }
            System.out.println("Lowest number is:" + lowest);
            System.out.println("Second lowest number is:" + slowest);
        }

        catch(IllegalArgumentException e)
        {
            System.out.println("An error occured");
        }
    }
    
}
