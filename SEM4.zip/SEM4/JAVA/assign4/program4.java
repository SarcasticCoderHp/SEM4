import javax.swing.JOptionPane;

class OddException extends Exception
{
	public OddException(String message)
	{
		super(message);
	}
}

public class program4
{
	public static void main(String[] args) {	

		int invalidCount=0;

		try
		{
		 for(int i=0;i<5;i++)
		 {
		String s1 = JOptionPane.showInputDialog("Enter only even numbers:");
		int input = Integer.parseInt(s1);
	    
	    if(input%2!=0)
	    {
	    	throw new OddException("Number can't be odd");
	    }

	    else
	    {
	    	System.out.println("Even numbers are:" + input);
	    }
	}
}

catch(OddException e)
{
	System.out.println(e.getMessage());
	invalidCount++;
}
System.out.println("Invalid numbers count:" + invalidCount);
}
}