import java.util.Scanner;

class CantVoteException extends Exception
{
    CantVoteException(String message)
    {
        super(message);
    }
}

public class program21 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your age:");
        int age = sc.nextInt();

        try
        {
            if(age<18)
            {
                throw new CantVoteException("You can't vote");
            }
            else
            {
                System.out.println("You can vote");
            }
        }

        catch(CantVoteException e)
        {
            System.out.println(e.getMessage());
        }
    }
    
}
