import java.util.Scanner;

public class program25 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string:");
        String input = sc.nextLine();
        StringBuffer str1 = new StringBuffer(input);

        System.out.println("Enter a string to append:");
        String input1 = sc.nextLine();
        StringBuffer str2 = new StringBuffer(input1);

        System.out.println("Appended string is:" + str1.append( str2));

        System.out.println("Capacity of modified string is:" + str1.capacity());

        System.out.println("Reversed string is:" + str1.reverse());
    }
}
