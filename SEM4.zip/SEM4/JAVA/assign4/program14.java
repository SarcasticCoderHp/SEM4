import java.util.Scanner;

class program14
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a number:");
		int num = sc.nextInt();

		try
		{
			if(num==0)
			{
				throw new NullPointerException();
			}
		
		else
		{
			System.out.print("Number is:" + num);
		}
	}
	catch(NullPointerException e)
	{
		System.out.print(e);
	}
}
}