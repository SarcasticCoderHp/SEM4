import java.util.Scanner;

public class program20 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        try
        {
            System.out.println("Enter a number:");
            String input = sc.nextLine();
            int num = Integer.parseInt(input);

            int result = 100/num;

            System.out.println("Result is:" + result);
        }

        catch(ArithmeticException e)
        {
            System.out.println("Number can't be zero in divide operation");
        }

        catch(NumberFormatException e)
        {
            System.out.println("Only integers allowed as number input");
        }

        catch(Exception e)
        {
            System.out.println("Some exception has occured");
        }
    }
}
