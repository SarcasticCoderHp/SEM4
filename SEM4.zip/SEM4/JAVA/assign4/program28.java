import java.util.Scanner;
import java.lang.StringBuffer;

public class program28 {

    public static void main(String[] args) {
     
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string:");
        String input = sc.nextLine();
        StringBuffer str1 = new StringBuffer(input);

        System.out.println("Replaced string is:" + str1.replace(0,4," Kava"));
        System.out.println("Reverse of string is:" + str1.reverse());
        System.out.println("Uppercase is:" + input.toUpperCase());
        System.out.println("Lowercase is:" + input.toLowerCase());
    }
}
