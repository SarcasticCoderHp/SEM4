import java.util.Scanner;

class DividebyzeroException extends Exception
{
    public DividebyzeroException(String message)
    {
        super(message);
    }
}

public class program18 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a numerator:");
        int num = sc.nextInt();

        System.out.println("Enter a denominator:");
        int den = sc.nextInt();

        try
        {
        if(den==0)
        {
            throw new DividebyzeroException("Denominator can't be zero");
        }
        else
        {
            int divide = num/den;
            System.out.println("Division is:" + divide);
        }
    }
    catch(DividebyzeroException e)
    {
        System.out.println(e.getMessage());
    }
}
}
