import java.util.Scanner;

class program22
{
  public static void main(String[] args) {
    
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter a string:");
    String str = sc.nextLine();

    //String class methods
    System.out.println("Uppercase is:" + str.toUpperCase());
    System.out.println("Lowercase is:" + str.toLowerCase());
    System.out.println("Trimmed string is:" + str.trim());
    System.out.println(str.startsWith("M"));
    System.out.println(str.endsWith("V"));
    System.out.println("Char at index 4 is:" + str.charAt(3));
    System.out.println("Length of string is:" + str.length());
    System.out.println("Replaced string(Java with Kava) is:" + str.replace("Java", "Kava"));
    System.out.println("Substring is:" + str.substring(11,15));
    
    String s1 = "String class of java";
    String s2 = "String class of java";
    System.out.println("String comparision is:" + s2.compareTo(s1));
    
    int a=10;
    String s = String.valueOf(a);
    System.out.println(s+10);

  }
}