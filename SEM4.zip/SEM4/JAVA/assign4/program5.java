import javax.swing.JOptionPane;

class noMatchException extends Exception
{
	public noMatchException(String message)
	{
		super(message);
	}
}

class program5
{
	public static void main(String[] args) throws noMatchException {

		String s1 = JOptionPane.showInputDialog("Enter a string(internet):");
		String s2 = "internet";

		try
		{
			if(s1.equals(s2))
			{
				System.out.println("Both strings equal");
			}
			else
			{
				throw new noMatchException("It is not equal to internet");
			}
		}

		catch(noMatchException e)
		{
			System.out.print(e.getMessage());
		}
	}
}