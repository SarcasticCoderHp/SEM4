public class program32 {
	public static void main(String[] args)
	{
		Byte B = new Byte((byte) 10);;
		byte b = B.byteValue();         

		Short S = new Short((short) 20);
		short s = S.shortValue();         

		Integer I = new Integer(15);  
		int i = I.intValue();          

		Long L = new Long(50);
		long l = L.longValue();    

		Float F = new Float(20);  
		float f = F.floatValue();   

		Double D = new Double(20.5);
		double d = D.doubleValue();   

		Boolean BLN = new Boolean(true);    
		boolean bln = BLN.booleanValue();    

		Character C = new Character('C');    
		char c = C.charValue();   
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(d);
		System.out.println(f);
		System.out.println(bln);
		System.out.println(c);
	}
}

