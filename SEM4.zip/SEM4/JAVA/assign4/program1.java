import java.util.Scanner;

public class program1
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int r,n,sum=0;
		try
		{
			System.out.println("Enter a number:");
		    n = sc.nextInt();
 
			if(n<=0)
			{
				throw new NullPointerException();
			}
			else
			{
                while(n!=0)
                {
                	r = n%10;
                	sum = sum+r;
                	n = n/10;
                }
                System.out.println("Sum of digits:" + sum);
			}

		}
		catch(NullPointerException e)
		{
			System.out.print("Number cant be less than or equal to zero");
		}
	}
}