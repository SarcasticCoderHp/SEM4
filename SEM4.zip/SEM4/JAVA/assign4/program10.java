import java.util.Scanner;

class SquareException extends Exception
{
    public SquareException(String message)
    {
        super(message);
    }
}

public class program10 {

    public static void main(String[] args) {
         
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a number:");
        int num = sc.nextInt();

        try
        {
            if(num<=0)
            {
                throw new SquareException("Number cant be less than or equal to zero");
            }
            else
            {
                int square = num*num;
                System.out.println("Square of number is:" + square);
            }
        }

        catch(SquareException e)
        {
            System.out.println(e.getMessage());
        }

    }
    
}
