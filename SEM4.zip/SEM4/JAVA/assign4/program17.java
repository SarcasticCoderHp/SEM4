import java.util.Scanner;

public class program17 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        try
        {
            System.out.println("Enter a string:");
            String s1 = sc.nextLine();

            if(s1.length()>0)
            {
                System.out.println("Enter start and end index for substring:");
                int sindex=sc.nextInt();
                int eindex=sc.nextInt();

               System.out.println(s1.substring(sindex, eindex));
            }
           else
           {
            throw new StringIndexOutOfBoundsException();
           }
        }

        catch(StringIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
    }
    
}
