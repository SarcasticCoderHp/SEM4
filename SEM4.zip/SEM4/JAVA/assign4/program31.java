     public class program31 {
            public static void main(String[] args) {
                
                Integer integerValue = Integer.valueOf(10);
                Double doubleValue = Double.valueOf(3.14);
                Boolean booleanValue = Boolean.valueOf(true);
        
                System.out.println("Integer Value: " + integerValue);
                System.out.println("Double Value: " + doubleValue);
                System.out.println("Boolean Value: " + booleanValue);
            }
        }
        
