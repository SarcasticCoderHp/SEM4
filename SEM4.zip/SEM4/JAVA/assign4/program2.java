import java.util.*;

class LengthMatchException extends Exception
{
	public LengthMatchException(String message)
	{
		super(message);
	}
}

public class program2
{
	public static void main(String[] args) throws LengthMatchException {
		
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a string:");
		String s1 = sc.nextLine();

		System.out.println("Enter a string length:");
		int length = sc.nextInt();

		try
		{
			if(s1.length()!=length)
			{
				throw new LengthMatchException("Length should be equal");
			}
			else
			{
				System.out.println("String is:" + s1);
				System.out.println("Length is:" + s1.length());
			}
		}
		catch(LengthMatchException e)
		{
			System.out.println(e.getMessage());
		}
	}
}