import java.util.Scanner;
import java.lang.StringBuffer;

public class program23 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a string:");
        String inputString = sc.nextLine();

        StringBuffer str1 = new StringBuffer(inputString);

        // StringBuffer class methods
        System.out.println("String capacity is:" + str1.capacity());
        System.out.println("Appended string is:" + str1.append(" Java uses stringbuffer"));
        System.out.println("Replaced string is:" + str1.replace(0, 3, "Kava"));
        System.out.println("Reversed string is:" + str1.reverse());
        str1.setCharAt(4, 'a'); 
        System.out.println("CharAt index 5 is:" + str1.charAt(4));
    }
}
