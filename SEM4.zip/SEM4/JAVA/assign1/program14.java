import java.util.Scanner;

class program14
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number:");
		int n,r,sum=0;

        n=sc.nextInt();
		int temp=n;

		while(n!=0)
		{
			r = n%10;
			sum = (sum*10) + r;
			n = n/10;
		}

		if(temp==sum)
		{
			System.out.println("It is palindrome");
		}
		else
		{
			System.out.println("It is not palindrome");
		}
	}
}