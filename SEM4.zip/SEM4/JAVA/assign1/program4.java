import java.util.Scanner;

class program4
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number:");
		int a = sc.nextInt();

		int square = a*a;
		int cube =  a*a*a;

		System.out.println("Square is:"+square);
		System.out.println("Cube is:"+cube);
	}
}