import java.util.Scanner;

class program11
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter two numbers:");

		int a = sc.nextInt();
		int b = sc.nextInt();

		if(a>b)
		{
			System.out.println(b + " is smaller");
		}
		else
		{
			System.out.println(a +" is smaller");
		}
	}
}