import java.util.Scanner;

class program10 {
    private double feet;

    public program10(program10 original) {
        this.feet = original.feet;
    }

    public program10(double feet) {
        this.feet = feet;
    }

    public double convertToCentimeters() {
        return feet * 30.48;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter length in feet: ");
        double inputFeet = scanner.nextDouble();

        program10 originalLength = new program10(inputFeet);
        program10 convertedLength = new program10(originalLength);

        System.out.println("Before Conversion:");
        System.out.println("Length in feet: " + originalLength.feet);
        System.out.println("Length in centimeters: " + originalLength.convertToCentimeters());

        System.out.println("\nAfter Conversion:");
        System.out.println("Length in feet: " + convertedLength.feet);
        System.out.println("Length in centimeters: " + convertedLength.convertToCentimeters());

    
    }
}
