import java.util.Scanner;

class program9 {

    program9(double b,double h)
    {
        double area =  0.5 * b * h;
        System.out.println("Area of triangle:" + area);
    }

    program9(int l,int w)
    {
        int area =  l * w;
        System.out.println("Area of rectangle:" + area);
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the width and height of triangle:");
        double b = sc.nextDouble();
        double h = sc.nextDouble();

        System.out.print("Enter the length and width of rectangle:");
        int l = sc.nextInt();
        int w = sc.nextInt();

        program9 obj1 = new program9(b,h);
        program9 obj2 = new program9(l,w);


        
    }
    
}
