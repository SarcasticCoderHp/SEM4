import java.util.Scanner;

class program2
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
         
        System.out.print("Enter the farenheit:");
		double f = sc.nextDouble();

		double celcius = (f-32)/1.8;

		System.out.println("Celcius is"+celcius);
	}
}