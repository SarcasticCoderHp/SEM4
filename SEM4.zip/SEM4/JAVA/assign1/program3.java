import java.util.Scanner;

class program3
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter hourly pay:");
		int hour_salary = sc.nextInt();

        System.out.print("Enter working hours:");
		int work_hours = sc.nextInt();

		int gross_salary = hour_salary * work_hours;
		int net_salary = gross_salary - (15/2); //tax=7.5%

		System.out.println("Gross salary:"+gross_salary);
		System.out.println("Net salary:"+net_salary);


	}
}