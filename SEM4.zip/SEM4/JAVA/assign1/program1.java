import java.util.Scanner;

class program1
{
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter num1:");
		int a = sc.nextInt();

		 System.out.print("Enter num2:");
		int b = sc.nextInt();

		int sum=a+b;
		int sub=a-b;
		int mul=a*b;
		int div=a/b;

		System.out.println("Sum is:"+sum);
		System.out.println("Sub is:"+sub);
		System.out.println("Mul is:"+mul);
		System.out.println("Div is:"+div);


	}
}