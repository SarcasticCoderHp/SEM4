import java.util.Scanner;

class program12
{
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		System.out.print("Enter three numbers:");
        	int a = sc.nextInt();
        	int b = sc.nextInt();
        	int c = sc.nextInt();
		
		System.out.println("1.if-else ladder");
		System.out.println("2.Nested if-else");

		System.out.println("Enter option:");
       
        int option = sc.nextInt();

        if(option==1)
        {
        	
        	if(a>b && a>c)
        	{
        		System.out.println(a + " is largest");
        	}
        	else if(b>c && b>a)
        	{
        		System.out.println(b + " is largest");
        	}
        	else
        	{
        		System.out.println(c + " is largest");
        	}

        }

        else if(option==2)
        {
          
          if(a!=0)
          {
            if(a>b && a>c)
            {
            	System.out.println(a + " is largest");
            }
        }
        else
        {
            if(b>c && b>a)
        	{
        		System.out.println(b + " is largest");
        	}
        	else
        	{
        		System.out.println(c + " is largest");
        	}
         } 
        }

	}
}