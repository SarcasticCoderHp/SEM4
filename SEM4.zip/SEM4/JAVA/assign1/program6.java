import javax.swing.JOptionPane;

class program6
{
	public static void main(String[] args) {
		
         String year = JOptionPane.showInputDialog("Enter the year:");

         int y = Integer.parseInt(year);

         	if(y%4==0)
         	{
         		System.out.println("Leap year");
         	}
         	else
         	{
         		System.out.println("Not a leap year");
         	}
         

         
	}
}