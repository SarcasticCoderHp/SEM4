import javax.swing.JOptionPane;

class program7
{
    private int num;

    program7(int n)
{
    num=n;
}


public String Check()
{
    return (num%2==0)?"It is an Even number":"It is a Odd number";
}

public static void main(String[] args) {
    
    String num = JOptionPane.showInputDialog("Enter a number:");
    int temp = Integer.parseInt(num);

    program7 s1 = new program7(temp);

    String result = s1.Check();

     System.out.println(result);   

}
}
    
