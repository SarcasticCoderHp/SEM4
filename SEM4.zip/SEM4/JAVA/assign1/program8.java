import java.util.Scanner;

class program8 {

    program8(int a)
    {
        boolean flag = false;

        for(int i=2;i<=a/2;i++)
        {
            if(a%i==0)
            {
                flag = true;
                break;
            }
        }
        if(!flag)
        {
            System.out.println("It is prime number");
        }
        else
        {
            System.out.println("It is not a prime number");
        }
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number:");
        int a = sc.nextInt();

        program8 obj = new program8(a);
    }
}
