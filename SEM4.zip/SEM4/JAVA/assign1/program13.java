import java.util.Scanner;

public class program13 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your marks:");
        int marks = sc.nextInt();

        char grade;

        if(marks>600)
        {
            grade = 'A';
            System.out.println(grade);
        }
        else if(marks>550 && marks < 600)
        {
            grade = 'B';
            System.out.println(grade);
        }
        else if(marks > 500 && marks < 550)
        {
            grade = 'C';
            System.out.println(grade);
        }
        else if(marks > 400 && marks < 500)
        {
            grade = 'D';
            System.out.println(grade);
        }
        else
        {
            grade = 'E';
            System.out.println(grade);
        }

    }
    
}
