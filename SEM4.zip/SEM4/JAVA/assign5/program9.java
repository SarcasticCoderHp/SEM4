class Thread1 extends Thread
{

  public void run()
  {
    while(true)
    {
        try
        {
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        System.out.println("Thread 1");
    }
  }
}

class Thread2 extends Thread
{
  
 public void run()
  {
    while(true)
    {
        try
        {
            Thread.sleep(4000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        System.out.println("Thread 2");
    }
  }
}

class Thread3 extends Thread
{
   public void run()
  {
    while(true)
    {
        try
        {
            Thread.sleep(6000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        
        System.out.println("Thread 3");
    }
  }
}

public class program9 {

    public static void main(String[] args) {
        
    Thread1 t1 = new Thread1();
    Thread2 t2 = new Thread2();
    Thread3 t3 = new Thread3();

    System.out.println("Thread 1 id is:" + t1.getId());
    t1.setName("Hello world");
    System.out.println("Name of thread 1 is:" + t1.getName());

    t1.setPriority(Thread.MIN_PRIORITY); //1
    t2.setPriority(Thread.NORM_PRIORITY); //5
    t3.setPriority(Thread.MAX_PRIORITY); //10

    t1.start();
    t2.start();
    t3.start();
    
    }
}
