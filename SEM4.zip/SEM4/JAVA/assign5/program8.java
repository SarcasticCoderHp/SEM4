class Thread1 extends Thread
{
    public void run()
    {
        System.out.println("Odd numbers are:");
        for(int i=1;i<10;i++)
        {
            if(i%2!=0)
            {
                System.out.println(i);
            }
        }
    }
}

class Thread2 implements Runnable
{
    public void run()
    {
        System.out.println("Even numbers are:");
        for(int i=0;i<10;i++)
        {
            if(i%2==0)
            {
                System.out.println(i);
            }
        }
    }
}

public class program8 {

    public static void main(String[] args) {
        
        Thread1 t1 = new Thread1();

        Thread2 r2 = new Thread2();
        Thread t2 = new Thread(r2);

        
        t1.start();

        try
        {
            t1.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        t2.start();

    }
     
}
