class RunnableExe1 implements Runnable
{
    public void run()
    {
        System.out.println("This is example of Runnable interface");
    }
}

class RunnableExe2 implements Runnable
{
    public void run()
    {
        System.out.println("This is example of Runnable interface2");
    }
}

public class program3 {

    public static void main(String[] args) {
        
    RunnableExe1 r1 = new RunnableExe1();
    Thread t1 = new Thread(r1);

    RunnableExe2 r2 = new RunnableExe2();
    Thread t2 = new Thread(r2);

    t1.start();
    t2.start();

    }
}
