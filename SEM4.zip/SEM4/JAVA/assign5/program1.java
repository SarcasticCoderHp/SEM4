class Thread1 extends Thread
{
    public void run()
    {

        while(true)
        {
        try
        {
        Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        System.out.println("Thread1");

    }
}
}

class Thread2 extends Thread
{
     public void run()
    {
        while(true)
        {

        try
        {
           Thread.sleep(4000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        System.out.println("Thread2");
    }
}
}

class program1
{
    public static void main(String[] args) {

       Thread1 t1 = new Thread1();
       Thread2 t2 = new Thread2();

       t1.start();
       t2.start();
    }
}