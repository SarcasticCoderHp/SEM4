class Thread1 extends Thread
{
    int sum1;

    public void run()
    {
        sum1 = (1+2+3+4+5);
    }

    public int getSum()
    {
        return sum1;
    }
}

class Thread2 extends Thread
{
    int sum2;

    public void run()
    {
        sum2 = (6+7+8+9+10);
    }

    public int getSum()
    {
        return sum2;
    }
}

class Thread3 extends Thread
{
    int sum3;

    public void run()
    {
        sum3 = (11+12+13+14+15);
    }

    public int getSum()
    {
        return sum3;
    }
}

public class program10 {
    public static void main(String[] args) {
        
        Thread1 t1 = new Thread1();
        Thread2 t2 = new Thread2();
        Thread3 t3 = new Thread3();

        t1.start();
        t2.start();
        t3.start();

        try {                                    
            t1.join(); 
            t2.join(); 
            t3.join(); 
        } 
        catch (Exception e) {
            System.out.println(e);
        }

        int totalSum = t1.getSum() + t2.getSum() + t3.getSum();
        int average = totalSum/15;

        System.out.println("Total sum is:" + totalSum);
        System.out.println("Average is:" + average);
    }
}
