class Thread1 extends Thread
{
    public void run()
    {
        System.out.println("Even numbers are:");
        for(int i=0;i<50;i++)
        {
            if(i%2==0)
            {
                System.out.println(i);
            }
        }
    }
}

class Thread2 extends Thread
{
    public void run()
    {
        System.out.println("Odd numbers are:");
        for(int i=0;i<50;i++)
        {
            if(i%2!=0)
            {
                System.out.println(i);
            }
        }
    }
}

public class program2 {

    public static void main(String[] args) {
        
        Thread1 t1 = new Thread1();
        Thread2 t2 = new Thread2();

        t1.start();

        try
        {
        t1.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        t2.start();
    }
}
