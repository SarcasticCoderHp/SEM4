import java.applet.*;
import java.awt.*;

public class Myapplet1 extends Applet
{
    public void paint(Graphics g)
    {
        g.setColor(Color.yellow);
        g.fillOval(700, 400,250 ,250);
        g.setColor(Color.red);
        g.fillArc(770, 500, 100,    100, 180,180);
        g.setColor(Color.black);
        g.fillOval(750, 450, 50, 50);
        g.fillOval(850, 450, 50, 50);  
        
    }
}

/*<applet code="Myapplet1.class" width=500 height=500></applet>*/