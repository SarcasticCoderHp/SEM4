import java.applet.*;
import java.awt.*;

class Myapplet extends Applet
{
    public void paint(Graphics g)
    {
        g.setColor(Color.yellow);
        g.fillRect(565,205,310,362);
        g.setColor(Color.blue);
        g.fillRect(605,275,75,75);
        g.fillRect(752,275,75,75);
        g.fillRect(665,395,120,170);
        
    }
}

/*<applet code="Myapplet" width=500 height=500></applet> */